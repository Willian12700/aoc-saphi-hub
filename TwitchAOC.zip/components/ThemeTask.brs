sub init()
    m.top.functionName = "runThemeFetch"
end sub

sub runThemeFetch()
    di = CreateObject("roDeviceInfo")
    ips = di.GetIPAddrs()
    myIp = ""
    for each iface in ips
        val = ips[iface]
        if val <> invalid and val <> "" and val <> "127.0.0.1"
            myIp = val
            exit for
        end if
    end for

    tvTarget = "willian"
    if Instr(1, myIp, ".11") > 0
        tvTarget = "mae"
    else if Instr(1, myIp, ".8") > 0
        tvTarget = "willian"
    end if

    query = "?tv=" + tvTarget + "&ip=" + myIp

    ' 1. Try direct local LAN IP
    http1 = CreateObject("roUrlTransfer")
    port1 = CreateObject("roMessagePort")
    http1.SetMessagePort(port1)
    http1.SetCertificatesFile("common:/certs/ca-bundle.crt")
    http1.InitClientCertificates()
    http1.AddHeader("User-Agent", "RokuHub/2.0")
    http1.SetUrl("http://192.168.1.7:8080/api/theme" + query)
    
    if http1.AsyncGetToString()
        msg = wait(2000, port1)
        if type(msg) = "roUrlEvent"
            body = msg.GetString()
            if body <> invalid and body <> "" and Instr(1, body, "accentColor") > 0
                m.top.themeJson = body
                return
            end if
        else
            http1.AsyncCancel()
        end if
    end if

    ' 2. Fallback to Cloudflare Tunnel
    http2 = CreateObject("roUrlTransfer")
    port2 = CreateObject("roMessagePort")
    http2.SetMessagePort(port2)
    http2.SetCertificatesFile("common:/certs/ca-bundle.crt")
    http2.InitClientCertificates()
    http2.AddHeader("User-Agent", "RokuHub/2.0")
    http2.SetUrl("https://aoc-saphi-hub.onrender.com/api/theme" + query)
    
    if http2.AsyncGetToString()
        msg = wait(4000, port2)
        if type(msg) = "roUrlEvent"
            body = msg.GetString()
            if body <> invalid and body <> "" and Instr(1, body, "accentColor") > 0
                m.top.themeJson = body
                return
            end if
        else
            http2.AsyncCancel()
        end if
    end if
end sub
