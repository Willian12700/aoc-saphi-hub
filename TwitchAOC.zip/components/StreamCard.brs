sub init()
    m.cardThumb = m.top.findNode("cardThumb")
    m.liveBadgeGroup = m.top.findNode("liveBadgeGroup")
    m.liveBadgeBg = m.top.findNode("liveBadgeBg")
    m.liveBadgeText = m.top.findNode("liveBadgeText")
    m.cardTitle = m.top.findNode("cardTitle")
    m.cardSub = m.top.findNode("cardSub")
end sub

sub onItemContentChange()
    item = m.top.itemContent
    if item = invalid then return

    ' 1. Title
    if item.title <> invalid then m.cardTitle.text = item.title else m.cardTitle.text = ""

    ' 2. Category / Subtitle
    if item.description <> invalid and item.description <> ""
        m.cardSub.text = item.description
    else if item.game <> invalid and item.game <> ""
        m.cardSub.text = item.game
    else
        m.cardSub.text = ""
    end if

    ' 3. Thumbnail Poster
    if item.HDPosterUrl <> invalid and item.HDPosterUrl <> ""
        m.cardThumb.uri = item.HDPosterUrl
    else
        m.cardThumb.uri = "pkg:/images/card_placeholder.png"
    end if

    ' 4. Live Badge Pill
    if item.HasField("isLive") and item.isLive = false
        m.liveBadgeGroup.visible = true
        m.liveBadgeBg.color = "0x52525BFF"
        m.liveBadgeText.color = "0xA1A1AAFF"
        m.liveBadgeText.text = "OFFLINE"
    else
        m.liveBadgeGroup.visible = true
        bColor = "0xEB0400FF"
        bText = "AO VIVO"
        if item.HasField("badgeColor") and item.badgeColor <> "" then bColor = item.badgeColor
        if item.HasField("badgeText") and item.badgeText <> "" then bText = item.badgeText
        m.liveBadgeBg.color = bColor
        m.liveBadgeText.text = bText
        m.liveBadgeText.color = "0xFFFFFFFF"
    end if
end sub
