sub init()
    m.top.functionName = "runChatFetch"
end sub

sub runChatFetch()
    login = m.top.channelLogin
    if login = invalid or login = "" then return

    ' 1. Try direct local PC
    http1 = CreateObject("roUrlTransfer")
    port1 = CreateObject("roMessagePort")
    http1.SetMessagePort(port1)
    http1.SetCertificatesFile("common:/certs/ca-bundle.crt")
    http1.InitClientCertificates()
    http1.AddHeader("User-Agent", "RokuHub/2.0")
    http1.SetUrl("http://192.168.1.7:8080/api/chat?channel=" + login)

    if http1.AsyncGetToString()
        msg = wait(1500, port1)
        if type(msg) = "roUrlEvent"
            body = msg.GetString()
            if body <> invalid and body <> "" and Left(body, 1) = "["
                m.top.responseJson = body
                return
            end if
        else
            http1.AsyncCancel()
        end if
    end if

    ' 2. Fallback to Cloudflare Tunnel
    http2 = CreateObject("roUrlTransfer")
    port2 = CreateObject("roMessagePort")
    http2.SetMessagePort(port2)
    http2.SetCertificatesFile("common:/certs/ca-bundle.crt")
    http2.InitClientCertificates()
    http2.AddHeader("User-Agent", "RokuHub/2.0")
    http2.SetUrl("https://aoc-saphi-hub.onrender.com/api/chat?channel=" + login)

    if http2.AsyncGetToString()
        msg = wait(2000, port2)
        if type(msg) = "roUrlEvent"
            body = msg.GetString()
            if body <> invalid and body <> "" and Left(body, 1) = "["
                m.top.responseJson = body
                return
            end if
        else
            http2.AsyncCancel()
        end if
    end if
end sub
