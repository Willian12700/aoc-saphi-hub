sub init()
    m.navList = m.top.findNode("navList")
    m.cardGrid = m.top.findNode("cardGrid")
    m.sectionTitle = m.top.findNode("sectionTitle")
    m.shelfTitle = m.top.findNode("shelfTitle")
    m.shelfCount = m.top.findNode("shelfCount")
    m.statusLabel = m.top.findNode("statusLabel")
    m.timeLabel = m.top.findNode("timeLabel")

    m.appWallpaper = m.top.findNode("appWallpaper")
    m.vignetteOverlay = m.top.findNode("vignetteOverlay")

    m.heroBackdrop = m.top.findNode("heroBackdrop")
    m.heroLiveBg = m.top.findNode("heroLiveBg")
    m.heroLiveText = m.top.findNode("heroLiveText")
    m.heroCatBg = m.top.findNode("heroCatBg")
    m.heroCatText = m.top.findNode("heroCatText")
    m.heroResBg = m.top.findNode("heroResBg")
    m.heroResText = m.top.findNode("heroResText")
    m.heroViewersText = m.top.findNode("heroViewersText")
    m.heroTitle = m.top.findNode("heroTitle")
    m.heroSubtitle = m.top.findNode("heroSubtitle")
    m.heroDesc = m.top.findNode("heroDesc")
    m.heroPlayBg = m.top.findNode("heroPlayBg")
    m.heroFavBg = m.top.findNode("heroFavBg")
    m.heroFavText = m.top.findNode("heroFavText")
    m.heroBtnFocus = m.top.findNode("heroBtnFocus")

    m.videoPlayer = m.top.findNode("videoPlayer")
    m.zappingOverlay = m.top.findNode("zappingOverlay")
    m.zappingTitle = m.top.findNode("zappingTitle")
    m.zappingHint = m.top.findNode("zappingHint")
    m.zappingAccent = m.top.findNode("zappingAccent")
    m.zappingTimer = m.top.findNode("zappingTimer")
    m.stallTimer = m.top.findNode("stallTimer")
    m.clockTimer = m.top.findNode("clockTimer")
    m.themePollTimer = m.top.findNode("themePollTimer")

    m.goalAlertGroup = m.top.findNode("goalAlertGroup")
    m.goalTitle = m.top.findNode("goalTitle")
    m.goalSub = m.top.findNode("goalSub")
    m.goalAlertTimer = m.top.findNode("goalAlertTimer")

    m.liveChatGroup = m.top.findNode("liveChatGroup")
    m.chatHeaderTitle = m.top.findNode("chatHeaderTitle")
    m.chatAccent = m.top.findNode("chatAccent")
    m.chatList = m.top.findNode("chatList")
    m.chatPollTimer = m.top.findNode("chatPollTimer")

    m.adShieldGroup = m.top.findNode("adShieldGroup")
    m.adShieldTitle = m.top.findNode("adShieldTitle")
    m.adShieldSub = m.top.findNode("adShieldSub")
    m.adPollTimer = m.top.findNode("adPollTimer")
    m.adCountdownTimer = m.top.findNode("adCountdownTimer")

    m.channelsData = []
    m.currentPlayingIdx = 0
    m.lastHlsUrl = ""
    m.hasPlayedOnce = false
    m.stallRetryCount = 0
    m.currentPlatform = ""
    m.currentLogin = ""
    m.currentDirectUrl = ""
    m.lastThemeVersion = 0
    m.lastGoalAlertId = 0
    m.activeGoalAlert = invalid
    m.chatTask = invalid
    m.adTask = invalid
    m.remainingAdSeconds = 0
    m.currentAdPosition = 0
    m.currentAdCount = 0
    m.favorites = loadFavorites()

    m.heroFocusedBtn = 0
    m.heroBtnFocus.visible = false
    m.currentReqType = "home"
    m.currentParam = ""
    m.currentSecTitle = "INÍCIO • EM ALTA NO STREAMING"
    m.currentShfTitle = "DESTAQUES RECOMENDADOS"

    setupNavMenu()

    m.navList.ObserveField("itemSelected", "onNavSelected")
    m.cardGrid.ObserveField("itemFocused", "onCardFocused")
    m.cardGrid.ObserveField("itemSelected", "onCardSelected")
    m.videoPlayer.ObserveField("state", "onVideoStateChange")
    m.zappingTimer.ObserveField("fire", "onZappingTimerFire")
    m.stallTimer.ObserveField("fire", "onStallTimerFire")
    m.clockTimer.ObserveField("fire", "updateClock")
    m.themePollTimer.ObserveField("fire", "pollThemeUpdate")
    m.appWallpaper.ObserveField("loadStatus", "onWallpaperLoadStatus")
    m.goalAlertTimer.ObserveField("fire", "onGoalAlertTimerFire")
    m.chatPollTimer.ObserveField("fire", "fetchLiveChat")
    m.adPollTimer.ObserveField("fire", "fetchAdStatus")
    m.adCountdownTimer.ObserveField("fire", "onAdCountdownTick")

    m.clockTimer.control = "start"
    m.themePollTimer.control = "start"

    m.task = CreateObject("roSGNode", "TwitchTask")
    m.task.ObserveField("responseJson", "onStreamsLoaded")
    m.task.ObserveField("streamUrl", "onStreamUrlReady")
    m.task.errorMessage = ""
    m.task.ObserveField("errorMessage", "onTaskError")

    updateClock()
    pollThemeUpdate()

    m.navList.jumpToItem = 0
    loadCategory("home", "", "INÍCIO • EM ALTA NO STREAMING", "DESTAQUES RECOMENDADOS")
end sub

sub updateClock()
    dt = CreateObject("roDateTime")
    dt.ToLocalTime()
    h = dt.GetHours().ToStr()
    if Len(h) = 1 then h = "0" + h
    mStr = dt.GetMinutes().ToStr()
    if Len(mStr) = 1 then mStr = "0" + mStr
    m.timeLabel.text = h + ":" + mStr
end sub

sub pollThemeUpdate()
    updateClock()
    if m.themeTask <> invalid
        m.themeTask.unobserveField("themeJson")
        m.themeTask.control = "STOP"
    end if
    m.themeTask = CreateObject("roSGNode", "ThemeTask")
    m.themeTask.ObserveField("themeJson", "onThemeUpdated")
    m.themeTask.control = "RUN"
end sub

sub onThemeUpdated()
    raw = m.themeTask.themeJson
    if raw = invalid or raw = "" then return
    theme = ParseJson(raw)
    if theme = invalid or theme.accentColor = invalid then return

    ' Goal Notification Alert
    if theme.goalAlert <> invalid and theme.goalAlert.id <> invalid
        if theme.goalAlert.id <> m.lastGoalAlertId
            m.lastGoalAlertId = theme.goalAlert.id
            m.activeGoalAlert = theme.goalAlert
            m.goalTitle.text = theme.goalAlert.text
            if theme.goalAlert.sub <> invalid then m.goalSub.text = theme.goalAlert.sub
            m.goalAlertGroup.visible = true
            m.goalAlertTimer.control = "stop"
            m.goalAlertTimer.control = "start"
            print "[ROKU-GOAL] Goal alert triggered: " + theme.goalAlert.text
        end if
    end if

    if theme.updatedAt <> invalid and theme.updatedAt = m.lastThemeVersion
        return
    end if
    if theme.updatedAt <> invalid then m.lastThemeVersion = theme.updatedAt

    print "[ROKU-THEME] applying theme=" + theme.themeName + " accent=" + theme.accentColor + " url=" + theme.fullWallpaperUrl

    if theme.fullWallpaperUrl <> invalid and theme.fullWallpaperUrl <> ""
        m.appWallpaper.uri = theme.fullWallpaperUrl
    end if
    if theme.accentColor <> invalid and theme.accentColor <> ""
        m.zappingAccent.color = theme.accentColor
        m.chatAccent.color = theme.accentColor
    end if
    if theme.wallpaperOpacity <> invalid
        op = theme.wallpaperOpacity
        if op < 0.15 then op = 0.15
        if op > 0.85 then op = 0.85
        darkness = 1.0 - op
        if darkness >= 0.75
            m.vignetteOverlay.color = "0x09090DF5"
        else if darkness >= 0.60
            m.vignetteOverlay.color = "0x09090DE6"
        else if darkness >= 0.45
            m.vignetteOverlay.color = "0x09090DCC"
        else
            m.vignetteOverlay.color = "0x09090DB3"
        end if
    end if
end sub

sub onGoalAlertTimerFire()
    m.goalAlertGroup.visible = false
end sub

sub onWallpaperLoadStatus()
    print "[ROKU-THEME] appWallpaper loadStatus=" + m.appWallpaper.loadStatus
end sub

function getTvProfileId() as String
    di = CreateObject("roDeviceInfo")
    ipList = di.GetIPAddrs()
    ipStr = ""
    if ipList <> invalid
        if ipList.eth0 <> invalid then ipStr = ipList.eth0
        if ipList.wifi0 <> invalid then ipStr = ipList.wifi0
    end if
    friendly = LCase(di.GetFriendlyName())
    if Instr(1, friendly, "willian") > 0 or Instr(1, ipStr, ".8") > 0
        return "willian"
    end if
    if Instr(1, friendly, "mae") > 0 or Instr(1, ipStr, ".11") > 0
        return "mae"
    end if
    return di.GetChannelClientId()
end function

function getTvProfileName() as String
    p = getTvProfileId()
    if p = "willian" then return "Quarto Willian"
    if p = "mae" then return "Quarto Mae"
    return "TV AOC"
end function

function loadFavorites() as Object
    tvProfile = getTvProfileId()
    secName = "TwitchAOC_" + tvProfile
    sec = CreateObject("roRegistrySection", secName)
    if sec.Exists("favorites")
        raw = sec.Read("favorites")
        if raw <> invalid and raw <> ""
            return raw.Split(",")
        end if
    end if
    if tvProfile = "mae"
        return ["globorn", "sbt", "record", "telecinepipoca", "megapix", "discoverykids", "chaves_24h"]
    else
        return ["premiere", "sportv", "espn", "gaules", "alanzoka", "loud_coringa", "chris_24h"]
    end if
end function

sub saveFavorites()
    tvProfile = getTvProfileId()
    secName = "TwitchAOC_" + tvProfile
    sec = CreateObject("roRegistrySection", secName)
    sec.Write("favorites", m.favorites.Join(","))
    sec.Flush()
end sub

function favKey(ch as Object) as String
    if ch = invalid then return ""
    if ch.platform <> invalid and ch.platform = "kick"
        return "kick:" + LCase(ch.login.Trim())
    end if
    if ch.login <> invalid
        return LCase(ch.login.Trim())
    end if
    return ""
end function

function isFavoriteChannel(ch as Object) as Boolean
    key = favKey(ch)
    if key = "" then return false
    for each f in m.favorites
        if LCase(f.Trim()) = key then return true
    end for
    return false
end function

sub toggleFavoriteChannel(ch as Object)
    key = favKey(ch)
    if key = "" then return
    newFavs = []
    found = false
    for each f in m.favorites
        if LCase(f.Trim()) = key
            found = true
        else if f.Trim() <> ""
            newFavs.Push(LCase(f.Trim()))
        end if
    end for
    if not found
        newFavs.Push(key)
        m.statusLabel.text = "★ Salvo nos Favoritos: " + ch.displayName
    else
        m.statusLabel.text = "★ Removido dos Favoritos: " + ch.displayName
    end if
    m.favorites = newFavs
    saveFavorites()

    idx = m.cardGrid.itemFocused
    if idx >= 0 and idx < m.channelsData.Count()
        updateHeroBannerFromIndex(idx)
    end if
end sub

sub setupNavMenu()
    content = CreateObject("roSGNode", "ContentNode")
    items = [
        "INICIO",
        "FUTEBOL AO VIVO",
        "SERIES & DESENHOS 24H",
        "TV ABERTA & NOTICIAS",
        "FILMES & ESPORTES 24H",
        "TWITCH BRASIL",
        "KICK BRASIL",
        "MEUS FAVORITOS",
        "BUSCAR CANAL",
        "ATUALIZAR"
    ]
    for each label in items
        node = content.CreateChild("ContentNode")
        node.title = label
    end for
    m.navList.content = content
end sub

sub loadCategory(reqType as String, param as String, secTitle as String, shfTitle as String)
    m.currentReqType = reqType
    m.currentParam = param
    m.currentSecTitle = secTitle
    m.currentShfTitle = shfTitle

    m.sectionTitle.text = secTitle
    m.shelfTitle.text = shfTitle
    m.shelfCount.text = "Sincronizando..."
    m.statusLabel.text = "ONLINE"

    m.task.control = "STOP"
    m.task.requestType = reqType
    m.task.queryParam = param
    m.task.control = "RUN"
end sub

sub onNavSelected()
    idx = m.navList.itemSelected
    profName = getTvProfileName()
    if idx = 0
        loadCategory("home", "", "INICIO - EM ALTA NO STREAMING", "DESTAQUES RECOMENDADOS")
    else if idx = 1
        loadCategory("partidas_hoje", "", "FUTEBOL - JOGOS DE HOJE AO VIVO", "PARTIDAS TRANSMITIDAS HOJE")
    else if idx = 2
        loadCategory("series_24h", "", "SERIES & DESENHOS 24H - MARATONAS", "CHAVES, CHRIS, DRAGON BALL, KENAN & KEL E ANIMACAO")
    else if idx = 3
        loadCategory("tv_aberta", "", "TV ABERTA & NOTICIAS - AO VIVO", "GLOBO RN, GLOBO SP, SBT, RECORD, BAND E NOTICIAS")
    else if idx = 4
        loadCategory("filmes_tv", "", "FILMES & ESPORTES - SINAIS 24H", "TELECINE, HBO, PREMIERE, SPORTV, ESPN E CINEMA")
    else if idx = 5
        loadCategory("top_pt", "", "TWITCH - TOP BRASIL AO VIVO", "STREAMERS EM ALTA NA TWITCH")
    else if idx = 6
        loadCategory("kick_pt", "", "KICK - TOP BRASIL AO VIVO", "STREAMERS EM ALTA NA KICK")
    else if idx = 7
        loadCategory("favorites", m.favorites.Join(","), "MEUS FAVORITOS - " + UCase(profName), "CANAIS SALVOS NA TV (" + profName + ")")
    else if idx = 8
        showKeyboardDialog("Buscar / Ir p/ Canal", "Digite o nome do streamer ou canal:", "search")
    else if idx = 9
        if m.currentReqType = "favorites"
            m.currentParam = m.favorites.Join(",")
        end if
        loadCategory(m.currentReqType, m.currentParam, m.currentSecTitle, m.currentShfTitle)
    end if
end sub

sub showKeyboardDialog(title as String, message as String, mode as String)
    m.kbMode = mode
    dialog = CreateObject("roSGNode", "KeyboardDialog")
    dialog.title = title
    dialog.message = [message]
    dialog.buttons = ["Confirmar", "Cancelar"]
    dialog.ObserveField("buttonSelected", "onKeyboardButton")
    m.top.dialog = dialog
end sub

sub onKeyboardButton()
    dialog = m.top.dialog
    if dialog = invalid then return
    btn = dialog.buttonSelected
    txt = dialog.text
    dialog.close = true
    if btn = 0 and txt <> invalid and txt.Trim() <> ""
        clean = txt.Trim()
        loadCategory("search", clean, "TWITCH BUSCA: " + UCase(clean), "RESULTADOS DA BUSCA")
    end if
end sub

sub onStreamsLoaded()
    raw = m.task.responseJson
    if raw = invalid or raw = "" then return
    parsed = ParseJson(raw)
    if parsed = invalid then return

    m.channelsData = parsed
    content = CreateObject("roSGNode", "ContentNode")

    for each ch in m.channelsData
        node = content.CreateChild("ContentNode")
        favStar = ""
        if isFavoriteChannel(ch) then favStar = "★ "

        node.title = favStar + ch.displayName
        node.description = ch.game

        if ch.thumb <> invalid and ch.thumb <> ""
            node.HDPosterUrl = ch.thumb
        else
            node.HDPosterUrl = "pkg:/images/card_placeholder.png"
        end if

        ' Badge styling
        bColor = "0xEB0400FF"
        bText = "AO VIVO"
        if ch.platform = "kick"
            bColor = "0x53FC18FF"
            bText = "KICK"
        else if ch.platform = "partidas"
            bColor = "0x10B981FF"
            bText = "FUTEBOL"
        else if ch.platform = "filmes"
            bColor = "0xF59E0BFF"
            bText = "CINEMA"
        end if

        node.addFields({
            isLive: ch.isLive,
            badgeColor: bColor,
            badgeText: bText
        })
    end for

    m.cardGrid.content = content
    count = m.channelsData.Count()
    print "[ROKU-STREAMS] loaded count=" + count.ToStr()
    m.shelfCount.text = count.ToStr() + " canais disponíveis"
    m.statusLabel.text = "● ONLINE • 1080p FULL HD"

    if count > 0
        m.cardGrid.jumpToItem = 0
        updateHeroBannerFromIndex(0)
        m.cardGrid.setFocus(true)
    else
        m.heroTitle.text = "Nenhum canal ativo agora"
        m.heroSubtitle.text = "Tente outra categoria no menu lateral"
        m.heroDesc.text = "Os canais esportivos e partidas ao vivo aparecem automaticamente nesta seção assim que os jogos começam."
        m.heroBackdrop.uri = "pkg:/images/card_placeholder.png"
        m.navList.setFocus(true)
    end if
end sub

function formatViewers(v as Integer) as String
    if v >= 1000
        k = Int(v / 100)
        whole = Int(k / 10).ToStr()
        dec = (k mod 10).ToStr()
        return whole + "." + dec + "K"
    end if
    return v.ToStr()
end function

sub onCardFocused()
    idx = m.cardGrid.itemFocused
    if idx < 0 or idx >= m.channelsData.Count() then return
    updateHeroBannerFromIndex(idx)
end sub

sub updateHeroBannerFromIndex(idx as Integer)
    if idx < 0 or idx >= m.channelsData.Count() then return
    ch = m.channelsData[idx]

    favTag = ""
    if isFavoriteChannel(ch)
        favTag = " *"
        m.heroFavText.text = "REMOVER"
    else
        m.heroFavText.text = "FAVORITAR"
    end if

    m.heroTitle.text = ch.displayName + favTag
    m.heroSubtitle.text = ch.game
    m.heroDesc.text = ch.title

    if ch.isLive
        if ch.platform = "kick"
            m.heroLiveBg.color = "0x53FC18FF"
            m.heroLiveText.color = "0x09090BFF"
            m.heroLiveText.text = "KICK LIVE"
            m.heroCatText.text = "KICK BRASIL"
        else if ch.platform = "partidas"
            m.heroLiveBg.color = "0x10B981FF"
            m.heroLiveText.color = "0xFFFFFFFF"
            m.heroLiveText.text = "FUTEBOL"
            m.heroCatText.text = "TRANSMISSÃO AO VIVO"
        else if ch.platform = "filmes"
            m.heroLiveBg.color = "0xF59E0BFF"
            m.heroLiveText.color = "0x09090BFF"
            m.heroLiveText.text = "24 HORAS"
            m.heroCatText.text = "CINEMA & SÉRIES"
        else
            m.heroLiveBg.color = "0xEB0400FF"
            m.heroLiveText.color = "0xFFFFFFFF"
            m.heroLiveText.text = "AO VIVO"
            m.heroCatText.text = "TWITCH LIVE"
        end if
        m.heroViewersText.text = formatViewers(ch.viewers) + " assistindo"
    else
        m.heroLiveBg.color = "0x52525BFF"
        m.heroLiveText.color = "0xA1A1AAFF"
        m.heroLiveText.text = "OFFLINE"
        m.heroViewersText.text = "Canal offline no momento"
    end if

    if ch.thumb <> invalid and ch.thumb <> ""
        m.heroBackdrop.uri = ch.thumb
    else
        m.heroBackdrop.uri = "pkg:/images/card_placeholder.png"
    end if
end sub

sub onCardSelected()
    idx = m.cardGrid.itemSelected
    if idx < 0 or idx >= m.channelsData.Count() then return
    playChannelByIndex(idx)
end sub

sub playChannelByIndex(idx as Integer)
    if idx < 0 or idx >= m.channelsData.Count() then return
    m.currentPlayingIdx = idx
    ch = m.channelsData[idx]
    plat = "twitch"
    if ch.platform <> invalid then plat = ch.platform
    pb = ""
    if ch.playbackUrl <> invalid then pb = ch.playbackUrl
    total = m.channelsData.Count()
    showZappingBanner("[" + (idx + 1).ToStr() + "/" + total.ToStr() + "] " + ch.displayName + " • " + ch.game)
    startChannelPlayback(plat, ch.login, ch.displayName, pb)
end sub

sub showZappingBanner(textStr as String)
    m.zappingTitle.text = textStr
    m.zappingOverlay.visible = true
    m.zappingTimer.control = "stop"
    m.zappingTimer.control = "start"
end sub

sub onZappingTimerFire()
    m.zappingOverlay.visible = false
end sub

sub zapChannel(delta as Integer)
    count = m.channelsData.Count()
    if count <= 0 then return
    nextIdx = m.currentPlayingIdx + delta
    if nextIdx < 0
        nextIdx = count - 1
    else if nextIdx >= count
        nextIdx = 0
    end if
    m.cardGrid.jumpToItem = nextIdx
    updateHeroBannerFromIndex(nextIdx)
    playChannelByIndex(nextIdx)
end sub

sub startChannelPlayback(platform as String, login as String, displayName as String, directPlaybackUrl as String)
    m.playingTitle = displayName
    m.currentPlatform = platform
    m.currentLogin = login
    m.currentDirectUrl = directPlaybackUrl
    m.stallRetryCount = 0
    m.stallTimer.control = "stop"
    if directPlaybackUrl <> ""
        m.statusLabel.text = "● Conectando live de " + displayName + "..."
        playHlsUrlNow(directPlaybackUrl)
        return
    end if
    m.statusLabel.text = "● Sintonizando transmissao de " + displayName + "..."
    m.task.control = "STOP"
    m.task.streamUrl = ""
    m.task.errorMessage = ""
    if platform = "kick"
        m.task.requestType = "kick_play"
    else if platform = "pluto"
        m.task.requestType = "pluto_play"
    else if platform = "partidas" or platform = "filmes"
        m.task.requestType = "partidas_play"
    else
        m.task.requestType = "play"
    end if
    m.task.queryParam = login
    m.task.control = "RUN"
end sub

sub onStreamUrlReady()
    url = m.task.streamUrl
    if url = invalid or url = "" then return
    playHlsUrlNow(url)
end sub

sub playHlsUrlNow(url as String)
    m.lastHlsUrl = url
    m.hasPlayedOnce = false
    m.videoPlayer.control = "stop"
    m.videoPlayer.setCertificatesFile("common:/certs/ca-bundle.crt")
    m.videoPlayer.InitClientCertificates()

    videoContent = CreateObject("roSGNode", "ContentNode")
    videoContent.url = url
    videoContent.title = m.playingTitle
    videoContent.streamFormat = "hls"
    videoContent.live = true
    videoContent.HttpSendClientCertificates = true

    headers = [
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    ]
    if Instr(1, url, "domhsd.com") > 0 or Instr(1, url, "streamtp") > 0
        headers.Push("Referer: https://streamtp99a.sbs/")
    else if Instr(1, url, "cloudfront-net.lat") > 0 or Instr(1, url, "embedtv") > 0
        headers.Push("Referer: https://ww0.embedtv.cc/")
    end if

    videoContent.HttpHeaders = headers

    m.videoPlayer.content = videoContent
    m.videoPlayer.visible = true
    m.top.setFocus(true)
    m.videoPlayer.control = "play"
    m.stallTimer.control = "stop"
    m.stallTimer.duration = 10
    m.stallTimer.control = "start"
    m.statusLabel.text = "● Reproduzindo Ao Vivo: " + m.playingTitle

    if m.currentPlatform = "twitch"
        m.adPollTimer.control = "start"
        fetchAdStatus()
    else
        m.adPollTimer.control = "stop"
        m.adCountdownTimer.control = "stop"
        m.adShieldGroup.visible = false
    end if
end sub

sub onTaskError()
    err = m.task.errorMessage
    if err <> invalid and err <> ""
        m.statusLabel.text = "● " + err
    end if
end sub

sub onVideoStateChange()
    st = m.videoPlayer.state
    print "[ROKU-VIDEO] state=" + st + " errCode=" + m.videoPlayer.errorCode.ToStr() + " errMsg=" + m.videoPlayer.errorMsg
    if st = "playing"
        m.hasPlayedOnce = true
        m.stallRetryCount = 0
        m.stallTimer.control = "stop"
    else if st = "buffering"
        m.stallTimer.control = "stop"
        if m.hasPlayedOnce
            m.stallTimer.duration = 5
        else
            m.stallTimer.duration = 10
        end if
        m.stallTimer.control = "start"
    else if st = "error"
        m.stallTimer.control = "stop"
        if m.videoPlayer.visible and m.stallRetryCount < 2
            m.stallRetryCount = m.stallRetryCount + 1
            print "[ROKU-WATCHDOG] Video error, auto-retrying attempt=" + m.stallRetryCount.ToStr()
            showZappingBanner("⚡ Reconectando sinal ao vivo: " + m.playingTitle)
            if m.lastHlsUrl <> ""
                playHlsUrlNow(m.lastHlsUrl)
            else
                startChannelPlayback(m.currentPlatform, m.currentLogin, m.playingTitle, m.currentDirectUrl)
            end if
            return
        end if
        m.statusLabel.text = "● Erro ao reproduzir stream (" + m.videoPlayer.errorMsg + ")."
        stopVideoPlayer()
    else if st = "finished"
        m.stallTimer.control = "stop"
        if m.videoPlayer.visible and m.stallRetryCount < 2
            m.stallRetryCount = m.stallRetryCount + 1
            if m.lastHlsUrl <> ""
                playHlsUrlNow(m.lastHlsUrl)
                return
            end if
        end if
        stopVideoPlayer()
    end if
end sub

sub onStallTimerFire()
    if not m.videoPlayer.visible then return
    if m.videoPlayer.state = "buffering"
        m.stallRetryCount = m.stallRetryCount + 1
        print "[ROKU-WATCHDOG] Stuck at 33% buffering! Auto-recovering attempt=" + m.stallRetryCount.ToStr()
        showZappingBanner("⚡ Destravando sinal ao vivo: " + m.playingTitle)
        if m.stallRetryCount <= 2 and m.lastHlsUrl <> ""
            playHlsUrlNow(m.lastHlsUrl)
        else
            m.stallRetryCount = 0
            startChannelPlayback(m.currentPlatform, m.currentLogin, m.playingTitle, m.currentDirectUrl)
        end if
    end if
end sub

sub stopVideoPlayer()
    print "[ROKU-UI] Exiting video player, returning to home card grid"
    m.stallTimer.control = "stop"
    m.videoPlayer.control = "stop"
    m.videoPlayer.visible = false
    m.zappingOverlay.visible = false
    m.zappingTimer.control = "stop"
    m.liveChatGroup.visible = false
    m.chatPollTimer.control = "stop"
    m.adPollTimer.control = "stop"
    m.adCountdownTimer.control = "stop"
    m.adShieldGroup.visible = false
    clearHeroButtonFocus()
    m.cardGrid.setFocus(true)
end sub

sub setHeroButtonFocus(btnIdx as Integer)
    m.heroFocusedBtn = btnIdx
    if btnIdx = 0
        m.heroBtnFocus.translation = [-3, -3]
        m.heroBtnFocus.width = 226
        m.heroBtnFocus.height = 54
    else
        m.heroBtnFocus.translation = [237, -3]
        m.heroBtnFocus.width = 206
        m.heroBtnFocus.height = 54
    end if
    m.heroBtnFocus.visible = true
end sub

sub clearHeroButtonFocus()
    m.heroBtnFocus.visible = false
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false
    print "[ROKU-KEY] key=" + key + " inPlayer=" + m.videoPlayer.visible.ToStr()

    ' 1. Goal Alert Click Interception ([OK] jumps to match)
    if m.goalAlertGroup.visible
        if key = "OK" or key = "select"
            m.goalAlertGroup.visible = false
            m.goalAlertTimer.control = "stop"
            if m.activeGoalAlert <> invalid and m.activeGoalAlert.channelLogin <> invalid and m.activeGoalAlert.channelLogin <> ""
                startChannelPlayback("partidas", m.activeGoalAlert.channelLogin, m.activeGoalAlert.channelName, "")
            else
                loadCategory("partidas_hoje", "", "FUTEBOL • JOGOS DE HOJE AO VIVO", "PARTIDAS TRANSMITIDAS HOJE")
            end if
            return true
        else if key = "back"
            m.goalAlertGroup.visible = false
            m.goalAlertTimer.control = "stop"
            return true
        end if
    end if

    ' 2. Video Player Key Navigation
    if m.videoPlayer.visible
        if key = "back"
            if m.liveChatGroup.visible
                toggleLiveChat()
                return true
            end if
            stopVideoPlayer()
            return true
        else if key = "right" or key = "replay" or key = "play" or key = "fastforward"
            toggleLiveChat()
            return true
        else if key = "left" and m.liveChatGroup.visible
            toggleLiveChat()
            return true
        else if key = "down" or key = "channelDown"
            zapChannel(1)
            return true
        else if key = "up" or key = "channelUp"
            zapChannel(-1)
            return true
        else if key = "options"
            if m.currentPlayingIdx >= 0 and m.currentPlayingIdx < m.channelsData.Count()
                toggleFavoriteChannel(m.channelsData[m.currentPlayingIdx])
                showZappingBanner("★ Favoritos: " + m.channelsData[m.currentPlayingIdx].displayName)
                return true
            end if
        else if key = "OK" or key = "select"
            if m.currentPlayingIdx >= 0 and m.currentPlayingIdx < m.channelsData.Count()
                ch = m.channelsData[m.currentPlayingIdx]
                showZappingBanner("[" + (m.currentPlayingIdx + 1).ToStr() + "/" + m.channelsData.Count().ToStr() + "] " + ch.displayName + " • " + ch.game)
            end if
            return true
        end if
        return false
    end if

    ' 3. Hero Buttons Focus Navigation
    if m.heroBtnFocus.visible
        if key = "down"
            clearHeroButtonFocus()
            m.cardGrid.setFocus(true)
            return true
        else if key = "right"
            if m.heroFocusedBtn = 0
                setHeroButtonFocus(1)
                return true
            end if
        else if key = "left"
            if m.heroFocusedBtn = 1
                setHeroButtonFocus(0)
                return true
            else
                clearHeroButtonFocus()
                m.navList.setFocus(true)
                return true
            end if
        else if key = "OK" or key = "select"
            idx = m.cardGrid.itemFocused
            if idx >= 0 and idx < m.channelsData.Count()
                if m.heroFocusedBtn = 0
                    playChannelByIndex(idx)
                else
                    toggleFavoriteChannel(m.channelsData[idx])
                end if
            end if
            return true
        else if key = "back"
            clearHeroButtonFocus()
            m.cardGrid.setFocus(true)
            return true
        end if
    end if

    ' 4. Card Grid Navigation
    if m.cardGrid.hasFocus()
        if key = "OK" or key = "select"
            idx = m.cardGrid.itemFocused
            if idx >= 0 and idx < m.channelsData.Count()
                playChannelByIndex(idx)
                return true
            end if
        else if key = "up"
            idx = m.cardGrid.itemFocused
            if idx < 5
                setHeroButtonFocus(0)
                return true
            end if
        else if key = "left"
            idx = m.cardGrid.itemFocused
            if (idx mod 5) = 0
                m.navList.setFocus(true)
                return true
            end if
        else if key = "options"
            idx = m.cardGrid.itemFocused
            if idx >= 0 and idx < m.channelsData.Count()
                toggleFavoriteChannel(m.channelsData[idx])
                return true
            end if
        else if key = "back"
            m.navList.setFocus(true)
            return true
        end if
    end if

    ' 5. Sidebar Navigation Rail
    if m.navList.hasFocus()
        if key = "OK" or key = "select"
            onNavSelected()
            return true
        else if key = "right"
            if m.channelsData.Count() > 0
                m.cardGrid.setFocus(true)
                return true
            end if
        else if key = "replay"
            onNavSelected()
            return true
        end if
    end if

    return false
end function

sub toggleLiveChat()
    m.liveChatGroup.visible = not m.liveChatGroup.visible
    if m.liveChatGroup.visible
        m.chatPollTimer.control = "start"
        fetchLiveChat()
        showZappingBanner("💬 Chat da Live ABERTO ([◀ Seta Esquerda] ou [Voltar] para fechar)")
    else
        m.chatPollTimer.control = "stop"
        showZappingBanner("💬 Chat da Live FECHADO ([▶ Seta Direita] para reabrir)")
    end if
end sub

sub fetchLiveChat()
    if not m.videoPlayer.visible or not m.liveChatGroup.visible or m.currentLogin = "" then return
    if m.chatTask <> invalid
        m.chatTask.unobserveField("responseJson")
        m.chatTask.control = "STOP"
    end if
    m.chatTask = CreateObject("roSGNode", "ChatTask")
    m.chatTask.channelLogin = m.currentLogin
    m.chatTask.ObserveField("responseJson", "onChatLoaded")
    m.chatTask.control = "RUN"
end sub

sub onChatLoaded()
    raw = m.chatTask.responseJson
    if raw = invalid or raw = "" or Left(raw, 1) <> "[" then return
    messages = ParseJson(raw)
    if messages = invalid or type(messages) <> "roArray" then return

    content = CreateObject("roSGNode", "ContentNode")
    for each msg in messages
        if msg.user <> invalid and msg.text <> invalid
            node = content.CreateChild("ContentNode")
            node.title = "[" + msg.time + "] " + msg.user + ": " + msg.text
        end if
    end for

    m.chatList.content = content
    cnt = content.getChildCount()
    if cnt > 0
        m.chatList.jumpToItem = cnt - 1
    end if
end sub

sub fetchAdStatus()
    if not m.videoPlayer.visible or m.currentPlatform <> "twitch" or m.currentLogin = ""
        m.adPollTimer.control = "stop"
        m.adCountdownTimer.control = "stop"
        m.adShieldGroup.visible = false
        return
    end if

    if m.adTask <> invalid
        m.adTask.unobserveField("responseJson")
        m.adTask.control = "STOP"
    end if
    m.adTask = CreateObject("roSGNode", "AdTask")
    m.adTask.channelLogin = m.currentLogin
    m.adTask.ObserveField("responseJson", "onAdStatusLoaded")
    m.adTask.control = "RUN"
end sub

sub onAdStatusLoaded()
    raw = m.adTask.responseJson
    if raw = invalid or raw = "" or Instr(1, raw, "isAd") = 0 then return
    data = ParseJson(raw)
    if data = invalid then return

    if data.isAd = true
        m.currentAdPosition = data.adPosition
        m.currentAdCount = data.adCount
        m.remainingAdSeconds = data.remainingSeconds
        m.adShieldTitle.text = "ANÚNCIO NA TWITCH (" + m.currentAdPosition.ToStr() + " de " + m.currentAdCount.ToStr() + ")"
        m.adShieldSub.text = "⏳ Restam " + m.remainingAdSeconds.ToStr() + "s para a live voltar"
        m.adShieldGroup.visible = true
        m.adCountdownTimer.control = "stop"
        m.adCountdownTimer.control = "start"
    else
        if m.adShieldGroup.visible
            m.adShieldGroup.visible = false
            m.adCountdownTimer.control = "stop"
        end if
    end if
end sub

sub onAdCountdownTick()
    if m.remainingAdSeconds > 0
        m.remainingAdSeconds = m.remainingAdSeconds - 1
        m.adShieldSub.text = "⏳ Restam " + m.remainingAdSeconds.ToStr() + "s para a live voltar"
    else
        m.adShieldGroup.visible = false
        m.adCountdownTimer.control = "stop"
    end if
end sub
