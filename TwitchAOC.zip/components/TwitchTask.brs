
function getKnownFavoriteChannel(id as String) as Dynamic
    clean = LCase(id.Trim())
    if Left(clean, 8) = "embedtv:" then clean = Mid(clean, 9)
    
    if clean = "globorn" or clean = "intertv" or clean = "cabugi"
        return { platform: "partidas", login: "embedtv:globorn", displayName: "TV Globo RN (InterTV Cabugi HD)", title: "Sinal regional da Rede Globo no Rio Grande do Norte", game: "TV Aberta & Noticias", viewers: 18000, thumb: "https://img.faz-o-eli.online/globorn.prev.png", playbackUrl: "", isLive: true }
    else if clean = "globosp"
        return { platform: "partidas", login: "embedtv:globosp", displayName: "TV Globo SP HD", title: "Programacao da Rede Globo Sao Paulo ao vivo 24 horas", game: "TV Aberta", viewers: 16000, thumb: "https://img.faz-o-eli.online/globosp.prev.png", playbackUrl: "", isLive: true }
    else if clean = "globorj"
        return { platform: "partidas", login: "embedtv:globorj", displayName: "TV Globo RJ HD", title: "Programacao da Rede Globo Rio de Janeiro ao vivo 24 horas", game: "TV Aberta", viewers: 15000, thumb: "https://img.faz-o-eli.online/globorj.prev.png", playbackUrl: "", isLive: true }
    else if clean = "sbt"
        return { platform: "partidas", login: "embedtv:sbt", displayName: "SBT HD", title: "Programacao do SBT com programas e novelas ao vivo", game: "TV Aberta", viewers: 11000, thumb: "https://img.faz-o-eli.online/sbt.prev.png", playbackUrl: "", isLive: true }
    else if clean = "record"
        return { platform: "partidas", login: "embedtv:record", displayName: "Record TV HD", title: "Jornalismo, novelas e realities da Record ao vivo 24h", game: "TV Aberta", viewers: 9500, thumb: "https://img.faz-o-eli.online/record.prev.png", playbackUrl: "", isLive: true }
    else if clean = "premiere" or clean = "premiereclubes"
        return { platform: "partidas", login: "embedtv:premiere", displayName: "Premiere Clubes 24h", title: "Brasileirao Serie A e Serie B Ao Vivo 24 horas", game: "Futebol Ao Vivo", viewers: 22000, thumb: "https://img.faz-o-eli.online/premiere.prev.png", playbackUrl: "", isLive: true }
    else if clean = "sportv"
        return { platform: "partidas", login: "embedtv:sportv", displayName: "SporTV 1 HD", title: "Futebol e programas esportivos ao vivo 24h", game: "Esportes 24h", viewers: 14000, thumb: "https://img.faz-o-eli.online/sportv.prev.png", playbackUrl: "", isLive: true }
    else if clean = "espn"
        return { platform: "partidas", login: "embedtv:espn", displayName: "ESPN 1 HD", title: "Futebol Internacional, Premier League e Libertadores", game: "Futebol Internacional", viewers: 13500, thumb: "https://img.faz-o-eli.online/espn.prev.png", playbackUrl: "", isLive: true }
    else if clean = "telecinepipoca"
        return { platform: "partidas", login: "embedtv:telecinepipoca", displayName: "Telecine Pipoca HD", title: "Grandes sucessos do cinema para toda a familia 24h", game: "Filmes 24h", viewers: 8900, thumb: "https://img.faz-o-eli.online/telecinepipoca.prev.png", playbackUrl: "", isLive: true }
    else if clean = "megapix"
        return { platform: "partidas", login: "embedtv:megapix", displayName: "Megapix HD", title: "Os maiores sucessos do cinema 100% dublados 24h", game: "Filmes 24h", viewers: 7800, thumb: "https://img.faz-o-eli.online/megapix.prev.png", playbackUrl: "", isLive: true }
    else if clean = "discoverykids"
        return { platform: "partidas", login: "embedtv:discoverykids", displayName: "Discovery Kids HD", title: "Desenhos educativos e infantis 24 horas", game: "Infantil 24h", viewers: 6500, thumb: "https://img.faz-o-eli.online/discoverykids.prev.png", playbackUrl: "", isLive: true }
    else if clean = "chaves_24h"
        return { platform: "twitch", login: "dynamic:chaves 24h:fosaus_odeia59", displayName: "Chaves 24 Horas", title: "Maratona 24 horas continuas de Chaves e Seu Madruga", game: "Serie Classica 24h", viewers: 8200, thumb: "https://i.ibb.co/23FwLv3K/par27.png", playbackUrl: "", isLive: true }
    else if clean = "chris_24h"
        return { platform: "twitch", login: "dynamic:todo mundo odeia o chris:noyciu_odeia59", displayName: "Todo Mundo Odeia o Chris 24h", title: "Maratona 24 horas de Todo Mundo Odeia o Chris dublado", game: "Comedia 24h", viewers: 9100, thumb: "https://i.ibb.co/23FwLv3K/par27.png", playbackUrl: "", isLive: true }
    else if clean = "dragonball_24h"
        return { platform: "twitch", login: "dynamic:dragon ball 24h:movieslivehd", displayName: "Dragon Ball Super & DBZ 24h", title: "Goku, Vegeta e as maiores batalhas de Dragon Ball 24h", game: "Anime 24h", viewers: 5400, thumb: "https://i.ibb.co/23FwLv3K/par27.png", playbackUrl: "", isLive: true }
    else if clean = "kenan_24h"
        return { platform: "pluto", login: "pluto:60f5fabf0721880007cd50e3", displayName: "Kenan & Kel (Nick Teen) 24h", title: "Kenan & Kel, Drake & Josh e series teen 24 horas ao vivo", game: "Series Teen 24h", viewers: 6700, thumb: "https://images.pluto.tv/channels/60f5fabf0721880007cd50e3/colorLogoPNG.png", playbackUrl: "", isLive: true }
    end if
    return invalid
end function

sub init()
    m.top.functionName = "executeRequest"
end sub

function postGql(gqlQuery as String) as Dynamic
    http = CreateObject("roUrlTransfer")
    port = CreateObject("roMessagePort")
    http.SetMessagePort(port)
    http.SetUrl("https://gql.twitch.tv/gql")
    http.SetCertificatesFile("common:/certs/ca-bundle.crt")
    http.InitClientCertificates()
    http.AddHeader("Client-ID", "kimne78kx3ncx6brgo4mv6wki5h1ko")
    http.AddHeader("Content-Type", "application/json")
    http.RetainBodyOnError(true)

    payload = FormatJson({ query: gqlQuery })
    if http.AsyncPostFromString(payload)
        msg = wait(12000, port)
        if type(msg) = "roUrlEvent"
            body = msg.GetString()
            if body <> invalid and body <> ""
                return ParseJson(body)
            end if
        end if
    end if
    return invalid
end function

function getJsonUrl(url as String) as Dynamic
    http = CreateObject("roUrlTransfer")
    port = CreateObject("roMessagePort")
    http.SetMessagePort(port)
    http.SetUrl(url)
    http.SetCertificatesFile("common:/certs/ca-bundle.crt")
    http.InitClientCertificates()
    http.AddHeader("User-Agent", "okhttp/4.12.0")
    http.AddHeader("Accept", "application/json")
    http.RetainBodyOnError(true)

    if http.AsyncGetToString()
        msg = wait(12000, port)
        if type(msg) = "roUrlEvent"
            body = msg.GetString()
            if body <> invalid and body <> ""
                return ParseJson(body)
            end if
        end if
    end if
    return invalid
end function

function getHtmlWithHeaders(url as String, referer as String) as String
    http = CreateObject("roUrlTransfer")
    port = CreateObject("roMessagePort")
    http.SetMessagePort(port)
    http.SetUrl(url)
    http.SetCertificatesFile("common:/certs/ca-bundle.crt")
    http.InitClientCertificates()
    http.AddHeader("User-Agent", "Mozilla/5.0 (Linux; Android 14; CPH2727 Build/UKQ1.231108.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/130.0.0.0 Mobile Safari/537.36")
    http.AddHeader("X-App-Token", "PARTIDAS2026")
    http.AddHeader("X-Requested-With", "com.partidas25.futeboldahoraaovivo")
    if referer <> ""
        http.AddHeader("Referer", referer)
    end if
    http.RetainBodyOnError(true)

    if http.AsyncGetToString()
        msg = wait(10000, port)
        if type(msg) = "roUrlEvent"
            body = msg.GetString()
            if body <> invalid then return body
        end if
    end if
    return ""
end function

function extractBetween(haystack as String, startMarker as String, endMarker as String) as String
    if haystack = "" then return ""
    p1 = Instr(1, haystack, startMarker)
    if p1 <= 0 then return ""
    p1 = p1 + Len(startMarker)
    p2 = Instr(p1, haystack, endMarker)
    if p2 <= 0 then return ""
    return Mid(haystack, p1, p2 - p1)
end function

function extractIframeSrc(raw as String) as String
    if raw = invalid or raw = "" then return ""
    s = extractBetween(raw, "src='", "'")
    if s <> "" then return s
    s = extractBetween(raw, "src=" + chr(34), chr(34))
    if s <> "" then return s
    return raw.Trim()
end function

sub executeRequest()
    reqType = m.top.requestType
    param = m.top.queryParam
    m.top.errorMessage = ""

    if reqType = "home"
        fetchHomeFeatured()
    else if reqType = "esportes_24h"
        fetchEsportes24h()
    else if reqType = "top_pt"
        q = "{ streams(first: 25, options: {broadcasterLanguages: [PT]}) { edges { node { broadcaster { login displayName } title viewersCount game { name } previewImageURL(width: 440, height: 248) } } } }"
        res = postGql(q)
        parseStreamsResponse(res)
    else if reqType = "top_global"
        q = "{ streams(first: 25) { edges { node { broadcaster { login displayName } title viewersCount game { name } previewImageURL(width: 440, height: 248) } } } }"
        res = postGql(q)
        parseStreamsResponse(res)
    else if reqType = "kick_pt"
        res = getJsonUrl("https://kick.com/stream/featured-livestreams/pt")
        parseKickFeaturedResponse(res)
    else if reqType = "kick_search"
        cleanSlug = LCase(param.Replace(" ", "-").Replace(chr(34), "").Trim())
        res = getJsonUrl("https://kick.com/api/v1/channels/" + cleanSlug)
        parseKickChannelResponse(res, cleanSlug)
    else if reqType = "series_24h"
        fetchSeriesEDesenhos24h()
    else if reqType = "tv_aberta"
        fetchTvAberta()
    else if reqType = "partidas_hoje"
        fetchPartidasDeHoje()
    else if reqType = "filmes_tv"
        fetchFilmesETv24h()
    else if reqType = "search"
        cleanParam = param.Replace(chr(34), "").Trim()
        q = "{ user(login: " + chr(34) + LCase(cleanParam) + chr(34) + ") { login displayName broadcastSettings { title } stream { viewersCount game { name } previewImageURL(width: 440, height: 248) } } searchFor(userQuery: " + chr(34) + cleanParam + chr(34) + ", platform: " + chr(34) + "web" + chr(34) + ") { channels { edges { item { ... on User { login displayName broadcastSettings { title } stream { viewersCount game { name } previewImageURL(width: 440, height: 248) } } } } } } }"
        res = postGql(q)
        parseSearchResponse(res)
    else if reqType = "favorites"
        parseFavoritesResponse(param)
    else if reqType = "play"
        fetchStreamHlsUrl(param.Trim())
    else if reqType = "kick_play"
        fetchKickHlsUrl(LCase(param.Trim()))
    else if reqType = "pluto_play"
        fetchPlutoHlsUrl(param.Trim())
    else if reqType = "partidas_play"
        fetchPartidasHlsUrl(param.Trim())
    end if
end sub

function guessEmbedTvChannel(title as String, category as String, sourcesStr as String) as String
    sLow = LCase(sourcesStr)
    cLow = LCase(category)
    tLow = LCase(title)
    if Instr(1, sLow, "sportynet") > 0 or Instr(1, sLow, "spnet") > 0 then return "sportynet"
    if Instr(1, sLow, "/xsp") > 0 or Instr(1, sLow, "xsports") > 0 then return "xsports"
    if Instr(1, sLow, "/pre1") > 0 or Instr(1, sLow, "premiere1") > 0 then return "premiere"
    if Instr(1, sLow, "/pre2") > 0 or Instr(1, sLow, "premiere2") > 0 then return "premiere2"
    if Instr(1, sLow, "/pre3") > 0 or Instr(1, sLow, "premiere3") > 0 then return "premiere3"
    if Instr(1, sLow, "/spo1") > 0 or Instr(1, sLow, "sportv1") > 0 then return "sportv"
    if Instr(1, sLow, "/spo2") > 0 or Instr(1, sLow, "sportv2") > 0 then return "sportv2"
    if Instr(1, sLow, "/spo3") > 0 or Instr(1, sLow, "sportv3") > 0 then return "sportv3"
    if Instr(1, sLow, "espn6") > 0 then return "espn6"
    if Instr(1, sLow, "espn5") > 0 then return "espn5"
    if Instr(1, sLow, "espn4") > 0 then return "espn4"
    if Instr(1, sLow, "espn3") > 0 then return "espn3"
    if Instr(1, sLow, "espn2") > 0 then return "espn2"
    if Instr(1, sLow, "espn") > 0 then return "espn"
    if Instr(1, sLow, "tnt") > 0 or Instr(1, sLow, "max") > 0 then return "tnt"
    if Instr(1, sLow, "caze") > 0 then return "sportv"
    if Instr(1, sLow, "globo") > 0 then return "globosp"

    if Instr(1, cLow, "série a") > 0 or Instr(1, cLow, "serie a") > 0 then return "premiere"
    if Instr(1, cLow, "série b") > 0 or Instr(1, cLow, "serie b") > 0 then return "premiere"
    if Instr(1, cLow, "russo") > 0 then return "xsports"
    if Instr(1, cLow, "italiano") > 0 then return "sportynet"
    if Instr(1, cLow, "inglês") > 0 or Instr(1, cLow, "ingles") > 0 then return "espn"
    if Instr(1, cLow, "espanhol 2") > 0 then return "espn4"
    if Instr(1, cLow, "espanhol") > 0 or Instr(1, cLow, "português") > 0 or Instr(1, cLow, "portugues") > 0 then return "espn2"
    if Instr(1, tLow, "santos") > 0 or Instr(1, tLow, "flamengo") > 0 or Instr(1, tLow, "corinthians") > 0 or Instr(1, tLow, "palmeiras") > 0 then return "premiere"
    return "sportv"
end function

sub fetchHomeFeatured()
    items = []

    ' 1. Fetch live matches of today (up to 3)
    pdh = getJsonUrl("https://novocapitulo.site/AM_BIBO_CONF27/PDH27.json")
    if pdh = invalid or pdh.channels = invalid or pdh.channels.Count() = 0
        pdh = getJsonUrl("https://minodobola.xyz/AM_BIBO_CONF27/PDH27.json")
    end if
    if pdh <> invalid and pdh.channels <> invalid
        addedCount = 0
        for each ch in pdh.channels
            if ch <> invalid and addedCount < 3
                title = "Partida de Hoje"
                if ch.title <> invalid and ch.title <> "" then title = ch.title
                cat = "Futebol Ao Vivo"
                if ch.category <> invalid and ch.category <> "" then cat = ch.category
                img = "https://i.ibb.co/23FwLv3K/par27.png"
                if ch.image <> invalid and ch.image <> "" then img = ch.image

                srcList = []
                for sIdx = 1 to 9
                    sKey = "source" + sIdx.ToStr()
                    if ch[sKey] <> invalid and ch[sKey] <> ""
                        cleanSrc = extractIframeSrc(ch[sKey])
                        if cleanSrc <> "" then srcList.Push(cleanSrc)
                    end if
                end for
                joinedSources = srcList.Join("|")
                fallbackCh = guessEmbedTvChannel(title, cat, joinedSources)
                if joinedSources <> ""
                    loginPayload = joinedSources + "|embedtv:" + fallbackCh + "|embedtv:premiere|embedtv:sportv|embedtv:espn"
                else
                    loginPayload = "embedtv:" + fallbackCh + "|embedtv:premiere|embedtv:sportv|embedtv:espn"
                end if
                items.Push({
                    platform: "partidas",
                    login: loginPayload,
                    displayName: title,
                    title: "Jogo de Hoje (" + cat + ") • Transmissao em Alta Definicao",
                    game: cat,
                    viewers: 24000,
                    thumb: img,
                    playbackUrl: "",
                    isLive: true
                })
                addedCount = addedCount + 1
            end if
        end for
    end if

    ' 2. Destaques TV Aberta & 24h em Alta
    destaques = [
        { id: "globorn", name: "TV Globo RN (InterTV Cabugi HD)", cat: "TV Aberta & Noticias", desc: "Sinal regional da Rede Globo no Rio Grande do Norte ao vivo 24 horas.", platform: "partidas", login: "embedtv:globorn", thumb: "https://img.faz-o-eli.online/globorn.prev.png", url: "" },
        { id: "chaves_24h", name: "Chaves 24 Horas", cat: "Serie Classica 24h", desc: "Maratona 24 horas continuas de Chaves, Seu Madruga, Quico e Dona Florinda.", platform: "twitch", login: "dynamic:chaves 24h:fosaus_odeia59", thumb: "https://i.ibb.co/23FwLv3K/par27.png", url: "" },
        { id: "chris_24h", name: "Todo Mundo Odeia o Chris 24h", cat: "Comedia 24h", desc: "Maratona 24 horas de Todo Mundo Odeia o Chris dublado em alta definicao.", platform: "twitch", login: "dynamic:todo mundo odeia o chris:noyciu_odeia59", thumb: "https://i.ibb.co/23FwLv3K/par27.png", url: "" },
        { id: "dragonball_24h", name: "Dragon Ball Super & DBZ 24h", cat: "Anime 24h", desc: "Goku, Vegeta e as maiores lutas do Torneio do Poder e sagas classicas 24h.", platform: "twitch", login: "dynamic:dragon ball 24h:movieslivehd", thumb: "https://i.ibb.co/23FwLv3K/par27.png", url: "" },
        { id: "kenan_24h", name: "Kenan & Kel (Nick Teen) 24h", cat: "Series Teen 24h", desc: "Kenan & Kel, Drake & Josh, iCarly e as melhores comedias teens 24h ao vivo.", platform: "pluto", login: "pluto:60f5fabf0721880007cd50e3", thumb: "https://images.pluto.tv/channels/60f5fabf0721880007cd50e3/colorLogoPNG.png", url: "" },
        { id: "premiere", name: "Premiere Clubes 24h", cat: "Brasileirao Serie A", desc: "Transmissao exclusiva dos jogos do Brasileirao Serie A e Serie B", platform: "partidas", login: "embedtv:premiere", thumb: "https://img.faz-o-eli.online/premiere.prev.png", url: "" },
        { id: "sportv", name: "SporTV 1 HD", cat: "Futebol & Programas", desc: "Futebol e programas esportivos ao vivo com debates e analises", platform: "partidas", login: "embedtv:sportv", thumb: "https://img.faz-o-eli.online/sportv.prev.png", url: "" }
    ]
    for each dt in destaques
        items.Push({
            platform: dt.platform,
            login: dt.login,
            displayName: dt.name,
            title: dt.desc,
            game: dt.cat,
            viewers: 16500,
            thumb: dt.thumb,
            playbackUrl: dt.url,
            isLive: true
        })
    end for

    ' 3. Top Cinema Channels
    topCinema = [
        { id: "telecinepremium", name: "Telecine Premium HD", cat: "Filmes 24h", desc: "Grandes estreias e sucessos de bilheteria do cinema mundial" },
        { id: "telecineaction", name: "Telecine Action HD", cat: "Acao & Suspense", desc: "Filmes de acao, adrenalina, suspense e velocidade 24 horas" },
        { id: "hbo", name: "HBO HD", cat: "Filmes & Series", desc: "Series originais consagradas da HBO e grandes lancamentos do cinema" },
        { id: "megapix", name: "Megapix HD", cat: "Filmes 24h", desc: "Grandes sucessos do cinema mundial 100% dublados 24 horas" },
        { id: "cartoonnetwork", name: "Cartoon Network HD", cat: "Desenhos 24h", desc: "Os melhores desenhos animados e producoes infantis 24 horas", directUrl: "http://45.162.64.114/CARTOON_NETWORK/tracks-v1a1/mono.ts.m3u8" }
    ]
    for each cm in topCinema
        pUrl = ""
        if cm.directUrl <> invalid then pUrl = cm.directUrl
        loginVal = "embedtv:" + cm.id
        if pUrl <> "" then loginVal = pUrl
        items.Push({
            platform: "partidas",
            login: loginVal,
            displayName: cm.name,
            title: cm.desc,
            game: cm.cat,
            viewers: 9800,
            thumb: "https://img.faz-o-eli.online/" + cm.id + ".prev.png",
            playbackUrl: pUrl,
            isLive: true
        })
    end for

    ' 4. Top Brazilian Twitch Streamers
    q = "{ streams(first: 6, options: {broadcasterLanguages: [PT]}) { edges { node { broadcaster { login displayName } title viewersCount game { name } previewImageURL(width: 440, height: 248) } } } }"
    res = postGql(q)
    if res <> invalid and res.data <> invalid and res.data.streams <> invalid and res.data.streams.edges <> invalid
        for each edge in res.data.streams.edges
            node = edge.node
            if node <> invalid and node.broadcaster <> invalid
                b = node.broadcaster
                gName = "Jogando"
                if node.game <> invalid and node.game.name <> invalid and node.game.name <> "" then gName = node.game.name
                items.Push({
                    platform: "twitch",
                    login: b.login,
                    displayName: b.displayName,
                    title: node.title,
                    game: gName,
                    viewers: node.viewersCount,
                    thumb: node.previewImageURL,
                    playbackUrl: "",
                    isLive: true
                })
            end if
        end for
    end if

    ' 5. Top Kick Streamers
    kickRes = getJsonUrl("https://kick.com/stream/featured-livestreams/pt")
    if kickRes <> invalid and kickRes.livestreams <> invalid
        kCount = 0
        for each ls in kickRes.livestreams
            if ls <> invalid and ls.channel <> invalid and kCount < 4
                ch = ls.channel
                session = ls
                slug = ch.slug
                dispName = ch.user.username
                gName = "Kick Live"
                if session.categories <> invalid and session.categories.Count() > 0
                    gName = session.categories[0].name
                end if
                thumbUrl = "pkg:/images/card_placeholder.png"
                if session.thumbnail <> invalid and session.thumbnail.url <> invalid
                    thumbUrl = session.thumbnail.url
                end if
                items.Push({
                    platform: "kick",
                    login: slug,
                    displayName: dispName,
                    title: session.session_title,
                    game: gName,
                    viewers: session.viewer_count,
                    thumb: thumbUrl,
                    playbackUrl: "",
                    isLive: true
                })
                kCount = kCount + 1
            end if
        end for
    end if

    m.top.responseJson = FormatJson(items)
end sub

sub fetchEsportes24h()
    items = []
    liveChannels = [
        { id: "premiere", name: "Premiere Clubes 24h", cat: "Futebol Ao Vivo", desc: "Brasileirao Serie A e Serie B Ao Vivo" },
        { id: "sportv", name: "SporTV 1 HD", cat: "Esportes 24h", desc: "Futebol e Programas Esportivos Ao Vivo" },
        { id: "sportv2", name: "SporTV 2 HD", cat: "Esportes 24h", desc: "Transmissoes Esportivas Ao Vivo" },
        { id: "sportv3", name: "SporTV 3 HD", cat: "Esportes 24h", desc: "Transmissoes Esportivas Ao Vivo" },
        { id: "espn", name: "ESPN 1 HD", cat: "Futebol Internacional", desc: "Premier League, LaLiga, Serie A Italiana e Libertadores" },
        { id: "espn2", name: "ESPN 2 HD", cat: "Futebol Internacional", desc: "Futebol Internacional Ao Vivo" },
        { id: "espn3", name: "ESPN 3 HD", cat: "Futebol Internacional", desc: "Esportes e Futebol Ao Vivo" },
        { id: "espn4", name: "ESPN 4 HD", cat: "Futebol Internacional", desc: "Futebol Europeu e Sul-Americano Ao Vivo" },
        { id: "espn5", name: "ESPN 5 HD", cat: "Futebol Internacional", desc: "Futebol Internacional e Esportes Ao Vivo" },
        { id: "espn6", name: "ESPN 6 HD", cat: "Futebol Internacional", desc: "Transmissoes Exclusivas ESPN Ao Vivo" },
        { id: "sportynet", name: "SportyNet HD", cat: "Futebol Europeu", desc: "Campeonato Italiano e Futebol Europeu Ao Vivo" },
        { id: "tnt", name: "TNT Sports / Max", cat: "Champions League", desc: "Champions League e Futebol Ao Vivo" },
        { id: "globosp", name: "TV Globo SP", cat: "Futebol na Globo", desc: "Futebol na Globo Sao Paulo Ao Vivo" },
        { id: "globorj", name: "TV Globo RJ", cat: "Futebol na Globo", desc: "Futebol na Globo Rio Ao Vivo" },
        { id: "globomg", name: "TV Globo MG", cat: "Futebol na Globo", desc: "Futebol na Globo Minas Ao Vivo" },
        { id: "sbt", name: "SBT Esporte", cat: "Futebol & Shows", desc: "Champions League e Sul-Americana Ao Vivo" },
        { id: "band", name: "Band Esporte", cat: "Futebol & Debates", desc: "Futebol Ao Vivo na Band" },
        { id: "bandsports", name: "BandSports HD", cat: "Esportes 24h", desc: "Futebol e Esportes 24h Ao Vivo" },
        { id: "record", name: "Record TV", cat: "TV Aberta & Futebol", desc: "Campeonato Brasileiro e Estaduais Ao Vivo" },
        { id: "xsports", name: "XSports HD", cat: "Esportes Mundiais", desc: "Jogos Internacionais Ao Vivo" },
        { id: "combate", name: "Combate HD", cat: "Lutas & UFC", desc: "Lutas e UFC Ao Vivo 24h" },
        { id: "premiere2", name: "Premiere 2", cat: "Brasileirao", desc: "Brasileirao Serie A e Serie B Ao Vivo" },
        { id: "premiere3", name: "Premiere 3", cat: "Brasileirao", desc: "Brasileirao Serie A e Serie B Ao Vivo" },
        { id: "premiere4", name: "Premiere 4", cat: "Brasileirao", desc: "Jogos Exclusivos Premiere Ao Vivo" },
        { id: "premiere5", name: "Premiere 5", cat: "Brasileirao", desc: "Jogos Exclusivos Premiere Ao Vivo" }
    ]
    for each lc in liveChannels
        items.Push({
            platform: "partidas",
            login: "embedtv:" + lc.id,
            displayName: lc.name,
            title: lc.desc,
            game: lc.cat,
            viewers: 2500,
            thumb: "https://img.faz-o-eli.online/" + lc.id + ".prev.png",
            playbackUrl: "",
            isLive: true
        })
    end for
    m.top.responseJson = FormatJson(items)
end sub


sub fetchSeriesEDesenhos24h()
    items = []
    series = [
        { id: "chaves_24h", name: "Chaves 24 Horas", cat: "Serie Classica 24h", desc: "Maratona 24 horas continuas de Chaves, Seu Madruga, Quico e Dona Florinda.", platform: "twitch", login: "dynamic:chaves 24h:fosaus_odeia59", thumb: "https://i.ibb.co/23FwLv3K/par27.png", url: "" },
        { id: "chris_24h", name: "Todo Mundo Odeia o Chris 24h", cat: "Comedia 24h", desc: "Maratona 24 horas de Todo Mundo Odeia o Chris dublado em alta definicao.", platform: "twitch", login: "dynamic:todo mundo odeia o chris:noyciu_odeia59", thumb: "https://i.ibb.co/23FwLv3K/par27.png", url: "" },
        { id: "dragonball_24h", name: "Dragon Ball Super & DBZ 24h", cat: "Anime 24h", desc: "Goku, Vegeta e as maiores lutas do Torneio do Poder e sagas classicas 24h.", platform: "twitch", login: "dynamic:dragon ball 24h:movieslivehd", thumb: "https://i.ibb.co/23FwLv3K/par27.png", url: "" },
        { id: "kenan_24h", name: "Kenan & Kel (Nick Teen) 24h", cat: "Series Teen 24h", desc: "Kenan & Kel, Drake & Josh, iCarly e as melhores comedias teens 24h ao vivo.", platform: "pluto", login: "pluto:60f5fabf0721880007cd50e3", thumb: "https://images.pluto.tv/channels/60f5fabf0721880007cd50e3/colorLogoPNG.png", url: "" },
        { id: "simpsons_24h", name: "Os Simpsons 24 Horas", cat: "Animacao 24h", desc: "Homer, Marge, Bart, Lisa e Maggie nas melhores temporadas 24 horas.", platform: "twitch", login: "dynamic:os simpsons 24h:alano2504", thumb: "https://i.ibb.co/23FwLv3K/par27.png", url: "" },
        { id: "southpark_24h", name: "South Park 24 Horas HD", cat: "Comedia Adulta 24h", desc: "Stan, Kyle, Cartman e Kenny nas aventuras mais acidas 24 horas em HD.", platform: "pluto", login: "pluto:609ae66b359b270007869ff1", thumb: "https://images.pluto.tv/channels/609ae66b359b270007869ff1/colorLogoPNG.png", url: "" },
        { id: "naruto_24h", name: "Naruto Shippuden 24 Horas", cat: "Anime 24h", desc: "A saga completa de Naruto Uzumaki em alta definicao 24 horas continuas.", platform: "pluto", login: "pluto:64c92f965580090008084968", thumb: "https://images.pluto.tv/channels/64c92f965580090008084968/colorLogoPNG.png", url: "" },
        { id: "onepiece_24h", name: "One Piece 24 Horas HD", cat: "Anime 24h", desc: "Luffy e o bando do Chapeu de Palha em busca do One Piece 24 horas ao vivo.", platform: "pluto", login: "pluto:624b1c8d4321e200073ee421", thumb: "https://images.pluto.tv/channels/624b1c8d4321e200073ee421/colorLogoPNG.png", url: "" },
        { id: "pokemon_24h", name: "Pokemon 24 Horas HD", cat: "Anime & Aventura 24h", desc: "Ash e Pikachu nas maiores jornadas e batalhas Pokemon 24 horas.", platform: "pluto", login: "pluto:687007a8ee4155e89a8f6d67", thumb: "https://images.pluto.tv/channels/687007a8ee4155e89a8f6d67/colorLogoPNG.png", url: "" },
        { id: "cartoonnetwork", name: "Cartoon Network HD 24h", cat: "Desenhos 24h", desc: "Hora de Aventura, Apenas um Show, Gumball e Ben 10 24h ao vivo.", platform: "partidas", login: "http://45.162.64.114/CARTOON_NETWORK/tracks-v1a1/mono.ts.m3u8", thumb: "https://img.faz-o-eli.online/cartoonnetwork.prev.png", url: "http://45.162.64.114/CARTOON_NETWORK/tracks-v1a1/mono.ts.m3u8" },
        { id: "boomerang", name: "Boomerang HD 24h", cat: "Desenhos Classicos", desc: "Tom & Jerry, Scooby-Doo, Looney Tunes e Flintstones 24 horas ao vivo.", platform: "partidas", login: "http://45.162.64.114/BOOMERANG/tracks-v1a1/mono.ts.m3u8", thumb: "https://img.faz-o-eli.online/cartoonnetwork.prev.png", url: "http://45.162.64.114/BOOMERANG/tracks-v1a1/mono.ts.m3u8" },
        { id: "retrocartoon", name: "Retro Cartoon HD 24h", cat: "Nostalgia 24h", desc: "Desenhos animados nostalgicos das decadas de 80 e 90 ao vivo 24h.", platform: "partidas", login: "https://stmv1.video.brstream.com.br/retrotv/retrotv/chunklist_w1069200121.m3u8", thumb: "https://img.faz-o-eli.online/cartoonnetwork.prev.png", url: "https://stmv1.video.brstream.com.br/retrotv/retrotv/chunklist_w1069200121.m3u8" },
        { id: "plutoclassicos", name: "Pluto Desenhos Classicos 24h", cat: "Animacao Classica", desc: "Popeye, Betty Boop, Gasparzinho e classicos da animacao 24h ao vivo.", platform: "pluto", login: "pluto:655e5c4d2c46f3000877a54b", thumb: "https://images.pluto.tv/channels/655e5c4d2c46f3000877a54b/colorLogoPNG.png", url: "" },
        { id: "trapalhoes_24h", name: "Os Trapalhoes 24 Horas", cat: "Comedia Brasileira 24h", desc: "Didi, Dede, Mussum e Zacarias nas melhores esquetes do humor nacional 24h.", platform: "pluto", login: "pluto:620d44093952ba0008986bb6", thumb: "https://images.pluto.tv/channels/620d44093952ba0008986bb6/colorLogoPNG.png", url: "" },
        { id: "bigbang_24h", name: "Big Bang A Teoria 24 Horas", cat: "Serie Comedia 24h", desc: "Sheldon Cooper, Leonard e os momentos mais engracados da serie 24 horas.", platform: "twitch", login: "dynamic:the big bang theory:mumeko_serie32", thumb: "https://i.ibb.co/23FwLv3K/par27.png", url: "" },
        { id: "doishomens_24h", name: "Dois Homens e Meio 24 Horas", cat: "Serie Comedia 24h", desc: "Charlie, Alan e Jake nas melhores temporadas em Malibu 24 horas ao vivo.", platform: "twitch", login: "dynamic:dois homens e meio:mumeko_serie32", thumb: "https://i.ibb.co/23FwLv3K/par27.png", url: "" }
    ]

    for each s in series
        items.Push({
            platform: s.platform,
            login: s.login,
            displayName: s.name,
            title: s.desc,
            game: s.cat,
            viewers: 7200,
            thumb: s.thumb,
            playbackUrl: s.url,
            isLive: true
        })
    end for
    m.top.responseJson = FormatJson(items)
end sub

sub fetchTvAberta()
    items = []
    openTv = [
        { id: "globorn", name: "TV Globo RN (InterTV Cabugi HD)", cat: "TV Aberta & Noticias", desc: "Sinal da Globo no Rio Grande do Norte com RN1, RN2 e noticias locais ao vivo.", directUrl: "" },
        { id: "globosp", name: "TV Globo SP HD", cat: "TV Aberta", desc: "Programacao oficial da Rede Globo Sao Paulo ao vivo 24 horas.", directUrl: "" },
        { id: "globorj", name: "TV Globo RJ HD", cat: "TV Aberta", desc: "Programacao oficial da Rede Globo Rio de Janeiro ao vivo 24 horas.", directUrl: "" },
        { id: "globomg", name: "TV Globo Minas HD", cat: "TV Aberta", desc: "Programacao oficial da Rede Globo Minas Gerais ao vivo 24 horas.", directUrl: "" },
        { id: "sbt", name: "SBT HD", cat: "TV Aberta", desc: "Programacao completa do SBT com jornalismo, programas e novelas ao vivo.", directUrl: "" },
        { id: "record", name: "Record TV HD", cat: "TV Aberta", desc: "Jornalismo, novelas, filmes e realities da Record ao vivo 24 horas.", directUrl: "" },
        { id: "band", name: "Band HD", cat: "TV Aberta", desc: "Esportes, Jogo Aberto, Brasil Urgente e jornalismo Band ao vivo.", directUrl: "" },
        { id: "cultura", name: "TV Cultura HD", cat: "TV Aberta", desc: "Cultura, jornalismo, infantil e educacao em alta definicao 24h.", directUrl: "http://45.162.64.114/TV_CULTURA/tracks-v1a1/mono.ts.m3u8" },
        { id: "aparecida", name: "TV Aparecida HD", cat: "TV Aberta", desc: "Transmissoes ao vivo, missas e programacao religiosa e familiar 24 horas.", directUrl: "http://45.162.64.114/TV_APARECIDA/tracks-v1a1/mono.ts.m3u8" },
        { id: "redetv", name: "RedeTV! HD", cat: "TV Aberta", desc: "Entretenimento, humor, esportes e jornalismo ao vivo.", directUrl: "" },
        { id: "globonews", name: "GloboNews HD", cat: "Noticias 24h", desc: "Jornalismo e noticias do Brasil e do mundo 24 horas no ar.", directUrl: "" },
        { id: "cnnbrasil", name: "CNN Brasil HD", cat: "Noticias 24h", desc: "Cobertura completa dos principais fatos do pais e do mundo ao vivo.", directUrl: "" },
        { id: "recordnews", name: "Record News HD", cat: "Noticias 24h", desc: "Canal de jornalismo 24 horas com debates e analises.", directUrl: "" }
    ]

    for each ot in openTv
        loginVal = "embedtv:" + ot.id
        if ot.directUrl <> "" then loginVal = ot.directUrl
        items.Push({
            platform: "partidas",
            login: loginVal,
            displayName: ot.name,
            title: ot.desc,
            game: ot.cat,
            viewers: 12000,
            thumb: "https://img.faz-o-eli.online/" + ot.id + ".prev.png",
            playbackUrl: ot.directUrl,
            isLive: true
        })
    end for
    m.top.responseJson = FormatJson(items)
end sub

sub fetchPartidasDeHoje()
    items = []
    ' 1. Fetch updated Partidas de Hoje v2 API (novocapitulo.site + minodobola.xyz backup)
    pdh = getJsonUrl("https://novocapitulo.site/AM_BIBO_CONF27/PDH27.json")
    if pdh = invalid or pdh.channels = invalid or pdh.channels.Count() = 0
        pdh = getJsonUrl("https://minodobola.xyz/AM_BIBO_CONF27/PDH27.json")
    end if

    if pdh <> invalid and pdh.channels <> invalid
        for each ch in pdh.channels
            if ch <> invalid
                title = "Partida de Hoje"
                if ch.title <> invalid and ch.title <> "" then title = ch.title
                cat = "Futebol Ao Vivo"
                if ch.category <> invalid and ch.category <> "" then cat = ch.category
                img = "https://i.ibb.co/23FwLv3K/par27.png"
                if ch.image <> invalid and ch.image <> "" then img = ch.image

                srcList = []
                for sIdx = 1 to 9
                    sKey = "source" + sIdx.ToStr()
                    if ch[sKey] <> invalid and ch[sKey] <> ""
                        cleanSrc = extractIframeSrc(ch[sKey])
                        if cleanSrc <> ""
                            srcList.Push(cleanSrc)
                        end if
                    end if
                end for

                joinedSources = srcList.Join("|")
                fallbackCh = guessEmbedTvChannel(title, cat, joinedSources)
                if joinedSources <> ""
                    loginPayload = joinedSources + "|embedtv:" + fallbackCh + "|embedtv:premiere|embedtv:sportv|embedtv:espn"
                    statusPrefix = "[AO VIVO] "
                    subTitle = "AO VIVO AGORA (" + cat + ") - " + srcList.Count().ToStr() + " opcoes de sinal"
                else
                    loginPayload = "embedtv:" + fallbackCh + "|embedtv:premiere|embedtv:sportv|embedtv:espn"
                    statusPrefix = "[HOJE] "
                    subTitle = "Jogo de Hoje (" + cat + ") - Sinal Principal: " + UCase(fallbackCh)
                end if

                items.Push({
                    platform: "partidas",
                    login: loginPayload,
                    displayName: title,
                    title: subTitle,
                    game: cat,
                    viewers: 1850,
                    thumb: img,
                    playbackUrl: "",
                    isLive: true
                })
            end if
        end for
    end if

    ' 2. Add 25 Verified Live 24h Brazilian Sports Channels (100% tested HTTP 200 OK)
    liveChannels = [
        { id: "premiere", name: "Premiere Clubes (24h)", desc: "Brasileirao Serie A e Serie B Ao Vivo" },
        { id: "sportv", name: "SporTV 1 HD", desc: "Futebol e Programas Esportivos Ao Vivo" },
        { id: "sportv2", name: "SporTV 2 HD", desc: "Transmissoes Esportivas Ao Vivo" },
        { id: "sportv3", name: "SporTV 3 HD", desc: "Transmissoes Esportivas Ao Vivo" },
        { id: "espn", name: "ESPN 1 HD", desc: "Premier League, LaLiga, Serie A Italiana e Libertadores" },
        { id: "espn2", name: "ESPN 2 HD", desc: "Futebol Internacional Ao Vivo" },
        { id: "espn3", name: "ESPN 3 HD", desc: "Esportes e Futebol Ao Vivo" },
        { id: "espn4", name: "ESPN 4 HD", desc: "Futebol Europeu e Sul-Americano Ao Vivo" },
        { id: "espn5", name: "ESPN 5 HD", desc: "Futebol Internacional e Esportes Ao Vivo" },
        { id: "espn6", name: "ESPN 6 HD", desc: "Transmissoes Exclusivas ESPN Ao Vivo" },
        { id: "sportynet", name: "SportyNet HD", desc: "Campeonato Italiano e Futebol Europeu Ao Vivo" },
        { id: "tnt", name: "TNT Sports / Max", desc: "Champions League e Futebol Ao Vivo" },
        { id: "globosp", name: "TV Globo SP", desc: "Futebol na Globo Sao Paulo Ao Vivo" },
        { id: "globorj", name: "TV Globo RJ", desc: "Futebol na Globo Rio Ao Vivo" },
        { id: "globomg", name: "TV Globo MG", desc: "Futebol na Globo Minas Ao Vivo" },
        { id: "sbt", name: "SBT Esporte", desc: "Champions e Sul-Americana Ao Vivo" },
        { id: "band", name: "Band Esporte", desc: "Futebol Ao Vivo na Band" },
        { id: "bandsports", name: "BandSports HD", desc: "Futebol e Esportes 24h Ao Vivo" },
        { id: "record", name: "Record TV", desc: "Campeonato Brasileiro e Estaduais Ao Vivo" },
        { id: "xsports", name: "XSports HD", desc: "Jogos Internacionais Ao Vivo" },
        { id: "combate", name: "Combate HD", desc: "Lutas e UFC Ao Vivo 24h" },
        { id: "premiere2", name: "Premiere 2", desc: "Brasileirao Serie A e Serie B Ao Vivo" },
        { id: "premiere3", name: "Premiere 3", desc: "Brasileirao Serie A e Serie B Ao Vivo" },
        { id: "premiere4", name: "Premiere 4", desc: "Jogos Exclusivos Premiere Ao Vivo" },
        { id: "premiere5", name: "Premiere 5", desc: "Jogos Exclusivos Premiere Ao Vivo" }
    ]

    for each lc in liveChannels
        items.Push({
            platform: "partidas",
            login: "embedtv:" + lc.id,
            displayName: lc.name,
            title: lc.desc,
            game: "Canal 24h",
            viewers: 2500,
            thumb: "https://img.faz-o-eli.online/" + lc.id + ".prev.png",
            playbackUrl: "",
            isLive: true
        })
    end for

    m.top.responseJson = FormatJson(items)
end sub



sub fetchFilmesETv24h()
    items = []
    movieChannels = [
        { id: "telecinepremium", name: "Telecine Premium HD", cat: "Filmes 24h", desc: "Lancamentos e grandes sucessos do cinema ao vivo", directUrl: "" },
        { id: "telecineaction", name: "Telecine Action HD", cat: "Filmes 24h", desc: "Filmes de acao, suspense e adrenalina 24h", directUrl: "" },
        { id: "telecinepipoca", name: "Telecine Pipoca HD", cat: "Filmes 24h", desc: "Blockbusters e diversao para toda a familia 24h", directUrl: "" },
        { id: "telecinefun", name: "Telecine Fun HD", cat: "Filmes 24h", desc: "Comedias e animacoes 24h ao vivo", directUrl: "" },
        { id: "telecinetouch", name: "Telecine Touch HD", cat: "Filmes 24h", desc: "Dramas e romances emocionantes 24h", directUrl: "" },
        { id: "telecinecult", name: "Telecine Cult HD", cat: "Filmes 24h", desc: "Classicos e cinema premiado 24h", directUrl: "" },
        { id: "hbo", name: "HBO HD", cat: "Filmes & Series", desc: "Series originais HBO e grandes filmes ao vivo", directUrl: "" },
        { id: "hbo2", name: "HBO 2 HD", cat: "Filmes & Series", desc: "Filmes e series dublados 24h ao vivo", directUrl: "" },
        { id: "hboplus", name: "HBO Plus HD", cat: "Filmes & Series", desc: "Sucessos de bilheteria e series HBO ao vivo", directUrl: "" },
        { id: "hbofamily", name: "HBO Family HD", cat: "Filmes & Familia", desc: "Filmes para toda a familia 24h", directUrl: "" },
        { id: "hboxtreme", name: "HBO Xtreme HD", cat: "Filmes & Acao", desc: "Acao intensa, ficcao e aventura 24h", directUrl: "" },
        { id: "megapix", name: "Megapix HD", cat: "Filmes 24h", desc: "Os maiores sucessos do cinema dublados 24h", directUrl: "" },
        { id: "tnt", name: "TNT HD", cat: "Filmes & Series", desc: "Blockbusters, premiacoes e grandes filmes 24h", directUrl: "" },
        { id: "space", name: "Space HD", cat: "Filmes & Series", desc: "Cinema de acao, terror, ficcao e lutas ao vivo", directUrl: "" },
        { id: "warnerchannel", name: "Warner Channel HD", cat: "Filmes & Series", desc: "Series de sucesso e grandes filmes da Warner 24h", directUrl: "" },
        { id: "studiouniversal", name: "Studio Universal HD", cat: "Filmes 24h", desc: "Grandes classicos e sucessos da Universal 24h", directUrl: "" },
        { id: "sonymovies", name: "Sony Movies HD", cat: "Filmes 24h", desc: "Sucessos do cinema da Sony em alta definicao 24h", directUrl: "http://45.162.64.114/SONY_MOVIES/tracks-v1a1/mono.ts.m3u8" },
        { id: "tntseries", name: "TNT Series HD", cat: "Series 24h", desc: "Maratonas de series policiais e de acao 24h", directUrl: "" },
        { id: "tntnovelas", name: "TNT Novelas HD", cat: "Novelas 24h", desc: "Grandes novelas e dramas internacionais 24h", directUrl: "" },
        { id: "amc", name: "AMC HD", cat: "Filmes & Series", desc: "Series exclusivas e filmes de acao ao vivo", directUrl: "" },
        { id: "axn", name: "AXN HD", cat: "Series 24h", desc: "Series de investigacao criminal e acao 24h", directUrl: "" },
        { id: "ae", name: "A&E HD", cat: "Series & Realities", desc: "Investigacao, realities policiais e filmes 24h", directUrl: "" },
        { id: "cartoonnetwork", name: "Cartoon Network HD", cat: "Desenhos 24h", desc: "Desenhos e animacoes ao vivo 24h (Sinal Estavel HD)", directUrl: "http://45.162.64.114/CARTOON_NETWORK/tracks-v1a1/mono.ts.m3u8" },
        { id: "retrocartoon", name: "Retro Cartoon HD", cat: "Desenhos Classicos", desc: "Desenhos classicos nostalgicos 24 horas ao vivo", directUrl: "https://stmv1.video.brstream.com.br/retrotv/retrotv/chunklist_w1069200121.m3u8" },
        { id: "adultswim", name: "Adult Swim HD", cat: "Animacao & Geek", desc: "Rick and Morty, animes e animacoes adultas 24h", directUrl: "" },
        { id: "discoverykids", name: "Discovery Kids HD", cat: "Infantil 24h", desc: "Desenhos educativos e infantis 24h", directUrl: "" },
        { id: "gloob", name: "Gloob HD", cat: "Infantil 24h", desc: "Miraculous, Detetives do Predio Azul e desenhos 24h", directUrl: "" },
        { id: "multishow", name: "Multishow HD", cat: "Variedades & Humor", desc: "Shows ao vivo, humor e realities 24h", directUrl: "" },
        { id: "bis", name: "Canal BIS HD", cat: "Musica & Shows", desc: "Shows internacionais e musica ao vivo 24h", directUrl: "" },
        { id: "mtv", name: "MTV HD", cat: "Musica & Realities", desc: "Clipes, musica e realities jovens 24h", directUrl: "" },
        { id: "gnt", name: "GNT HD", cat: "Variedades", desc: "Gastronomia, entrevistas e estilo de vida 24h", directUrl: "" },
        { id: "tlc", name: "TLC HD", cat: "Realities & Vida", desc: "Quilos Mortais, 90 Dias para Casar e realities 24h", directUrl: "" },
        { id: "off", name: "Canal OFF HD", cat: "Aventura & Surf", desc: "Esportes radicais, surf e natureza em HD 24h", directUrl: "" },
        { id: "discoverychannel", name: "Discovery Channel HD", cat: "Documentarios", desc: "Largados e Pelados, sobrevivencia e ciencia 24h", directUrl: "" },
        { id: "discoveryturbo", name: "Discovery Turbo HD", cat: "Carros & Motores", desc: "Carros classicos, oficinas, motores e velocidade 24h", directUrl: "" },
        { id: "history", name: "History Channel HD", cat: "Documentarios", desc: "Trato Feito, historia, misterios e documentarios 24h", directUrl: "" },
        { id: "history2", name: "History 2 (H2) HD", cat: "Documentarios", desc: "Historia profunda, ciencia e civilizacoes 24h", directUrl: "" },
        { id: "animalplanet", name: "Animal Planet HD", cat: "Natureza 24h", desc: "Vida selvagem e natureza em alta definicao 24h", directUrl: "" },
        { id: "discoveryworld", name: "Discovery World HD", cat: "Documentarios", desc: "Viagens, cultura mundial e documentarios em HD", directUrl: "" },
        { id: "discoveryscience", name: "Discovery Science HD", cat: "Ciencia & Espaco", desc: "Tecnologia, universo, engenharia e ciencia 24h", directUrl: "" },
        { id: "sbt", name: "SBT HD", cat: "TV Aberta", desc: "Programacao do SBT ao vivo 24 horas", directUrl: "" },
        { id: "record", name: "Record TV HD", cat: "TV Aberta", desc: "Jornalismo, novelas e realities da Record ao vivo", directUrl: "" },
        { id: "band", name: "Band HD", cat: "TV Aberta", desc: "Esportes, Jogo Aberto, Brasil Urgente e jornalismo", directUrl: "" },
        { id: "cultura", name: "TV Cultura HD", cat: "TV Aberta", desc: "Programacao cultural, jornalismo e infantil ao vivo", directUrl: "" },
        { id: "redetv", name: "RedeTV! HD", cat: "TV Aberta", desc: "Entretenimento, esportes e jornalismo ao vivo", directUrl: "" },
        { id: "aparecida", name: "TV Aparecida HD", cat: "TV Aberta", desc: "Programacao ao vivo 24 horas (Sinal Estavel HD)", directUrl: "http://45.162.64.114/TV_APARECIDA/tracks-v1a1/mono.ts.m3u8" },
        { id: "globonews", name: "GloboNews HD", cat: "Noticias 24h", desc: "Jornalismo e noticias ao vivo 24 horas", directUrl: "" },
        { id: "cnnbrasil", name: "CNN Brasil HD", cat: "Noticias 24h", desc: "Noticias do Brasil e do mundo ao vivo 24h", directUrl: "" },
        { id: "recordnews", name: "Record News HD", cat: "Noticias 24h", desc: "Jornalismo e informacao ao vivo 24h", directUrl: "" }
    ]

    for each mc in movieChannels
        loginVal = "embedtv:" + mc.id
        if mc.directUrl <> "" then loginVal = mc.directUrl
        items.Push({
            platform: "partidas",
            login: loginVal,
            displayName: mc.name,
            title: mc.desc,
            game: mc.cat,
            viewers: 3200,
            thumb: "https://img.faz-o-eli.online/" + mc.id + ".prev.png",
            playbackUrl: mc.directUrl,
            isLive: true
        })
    end for

    m.top.responseJson = FormatJson(items)
end sub

function isValidM3u8Url(m3u8Url as String, referer as String) as Boolean
    if m3u8Url = "" then return false
    body = getHtmlWithHeaders(m3u8Url, referer)
    if body <> "" and Instr(1, body, "#EXTM3U") > 0
        return true
    end if
    return false
end function

function resolveSinglePartidasSource(srcUrl as String) as String
    if srcUrl = "" then return ""
    if Left(srcUrl, 7) = "http://" or Left(srcUrl, 8) = "https://"
        if Instr(1, srcUrl, "embedtv") = 0 and Instr(1, srcUrl, "streamtp") = 0 and Instr(1, srcUrl, "global1.php") = 0
            return srcUrl
        end if
    end if

    if Left(srcUrl, 8) = "embedtv:"
        chId = Mid(srcUrl, 9)
        if chId = "premiere1" or chId = "premiereclubes" or chId = "premiere_clubes" then chId = "premiere"
        lanUrl = "http://192.168.1.7:8080/hls/" + chId + "/live.m3u8"
        if isValidM3u8Url(lanUrl, "")
            return lanUrl
        end if
        return "https://tigers-inches-legislature-largely.trycloudflare.com/hls/" + chId + "/live.m3u8"
    end if

    if Instr(1, srcUrl, "embedtv?id=") > 0
        p = Instr(1, srcUrl, "embedtv?id=")
        chId = Mid(srcUrl, p + 11)
        amp = Instr(1, chId, "&")
        if amp > 0 then chId = Left(chId, amp - 1)
        if chId = "premiere1" or chId = "premiereclubes" or chId = "premiere_clubes" then chId = "premiere"
        if Left(chId, 8) = "premiere"
            return "http://192.168.1.7:8080/hls/" + chId + "/live.m3u8"
        end if

        html = getHtmlWithHeaders("https://ww0.embedtv.cc/" + chId, "https://skyflowmino.space/")
        m3u8 = extractBetween(html, "const src = " + chr(34), chr(34))
        print "[ROKU-TASK] embedtv ch=" + chId + " htmlLen=" + Len(html).ToStr() + " m3u8=" + m3u8
        if m3u8 <> "" and isValidM3u8Url(m3u8, "https://ww0.embedtv.cc/")
            print "[ROKU-TASK] valid m3u8 confirmed!"
            return m3u8
        end if
        print "[ROKU-TASK] m3u8 invalid or empty!"
        return ""
    end if

    if Instr(1, srcUrl, "streamtp") > 0 or Instr(1, srcUrl, "global1.php") > 0
        html = getHtmlWithHeaders(srcUrl, "https://skyflowmino.space/")
        m3u8 = extractBetween(html, "var playbackURL = " + chr(34), chr(34))
        if m3u8 <> ""
            cleanM3u8 = m3u8.Replace("\/", "/")
            if isValidM3u8Url(cleanM3u8, "https://streamtp99a.sbs/")
                return cleanM3u8
            end if
        end if
        return ""
    end if

    if Instr(1, srcUrl, ".m3u8") > 0
        if isValidM3u8Url(srcUrl, "https://skyflowmino.space/")
            return srcUrl
        end if
    end if

    return ""
end function

sub fetchPartidasHlsUrl(param as String)
    parts = param.Split("|")
    ' 1. First prioritize embedtv sources (fastest, no IP-lock token issues on Roku)
    for each p in parts
        clean = p.Trim()
        if Instr(1, clean, "embedtv") > 0
            hls = resolveSinglePartidasSource(clean)
            if hls <> ""
                m.top.streamUrl = hls
                return
            end if
        end if
    end for

    ' 2. Next try streamtp / global1.php or direct m3u8 sources
    for each p in parts
        clean = p.Trim()
        if Instr(1, clean, "embedtv") = 0
            hls = resolveSinglePartidasSource(clean)
            if hls <> ""
                m.top.streamUrl = hls
                return
            end if
        end if
    end for

    m.top.errorMessage = "Sinal da partida indisponivel no momento."
    m.top.streamUrl = ""
end sub

sub parseKickFeaturedResponse(res as Dynamic)
    items = []
    if res <> invalid and res.data <> invalid
        for each st in res.data
            if st <> invalid and st.channel <> invalid
                slug = ""
                if st.channel.slug <> invalid then slug = st.channel.slug
                displayName = slug
                if st.channel.user <> invalid and st.channel.user.username <> invalid
                    displayName = st.channel.user.username
                end if
                title = ""
                if st.session_title <> invalid then title = st.session_title
                viewers = 0
                if st.viewer_count <> invalid then viewers = st.viewer_count
                gameName = "Kick Live"
                if st.categories <> invalid and st.categories.Count() > 0 and st.categories[0].name <> invalid
                    gameName = st.categories[0].name
                end if
                thumb = ""
                if st.thumbnail <> invalid and st.thumbnail.src <> invalid
                    thumb = st.thumbnail.src
                end if
                playbackUrl = ""
                if st.channel.playback_url <> invalid then playbackUrl = st.channel.playback_url

                if slug <> ""
                    items.Push({
                        platform: "kick",
                        login: slug,
                        displayName: "[KICK] " + displayName,
                        title: title,
                        game: gameName,
                        viewers: viewers,
                        thumb: thumb,
                        playbackUrl: playbackUrl,
                        isLive: true
                    })
                end if
            end if
        end for
    end if

    m.top.responseJson = FormatJson(items)
end sub



sub parseKickChannelResponse(res as Dynamic, fallbackSlug as String)
    items = []
    if res <> invalid and res.slug <> invalid
        slug = res.slug
        displayName = slug
        if res.user <> invalid and res.user.username <> invalid
            displayName = res.user.username
        end if
        playbackUrl = ""
        if res.playback_url <> invalid then playbackUrl = res.playback_url
        isLive = false
        title = "Canal na Kick"
        viewers = 0
        gameName = "Kick"
        thumb = ""
        if res.livestream <> invalid
            isLive = true
            if res.livestream.session_title <> invalid then title = res.livestream.session_title
            if res.livestream.viewer_count <> invalid then viewers = res.livestream.viewer_count
            if res.livestream.categories <> invalid and res.livestream.categories.Count() > 0 and res.livestream.categories[0].name <> invalid
                gameName = res.livestream.categories[0].name
            end if
            if res.livestream.thumbnail <> invalid and res.livestream.thumbnail.url <> invalid
                thumb = res.livestream.thumbnail.url
            end if
        end if
        items.Push({
            platform: "kick",
            login: slug,
            displayName: "[KICK] " + displayName,
            title: title,
            game: gameName,
            viewers: viewers,
            thumb: thumb,
            playbackUrl: playbackUrl,
            isLive: isLive
        })
    else
        m.top.errorMessage = "Canal da Kick nao encontrado: " + fallbackSlug
    end if
    m.top.responseJson = FormatJson(items)
end sub



sub fetchKickHlsUrl(slug as String)
    res = getJsonUrl("https://kick.com/api/v1/channels/" + slug)
    if res <> invalid and res.playback_url <> invalid and res.playback_url <> ""
        m.top.streamUrl = res.playback_url
        return
    end if
    m.top.errorMessage = "Canal da Kick offline ou indisponivel (" + slug + ")."
    m.top.streamUrl = ""
end sub

sub parseStreamsResponse(res as Dynamic)
    items = []
    if res <> invalid and res.data <> invalid and res.data.streams <> invalid and res.data.streams.edges <> invalid
        for each edge in res.data.streams.edges
            if edge <> invalid and edge.node <> invalid
                n = edge.node
                login = ""
                displayName = ""
                if n.broadcaster <> invalid
                    if n.broadcaster.login <> invalid then login = n.broadcaster.login
                    if n.broadcaster.displayName <> invalid then displayName = n.broadcaster.displayName
                end if
                gameName = "Ao Vivo"
                if n.game <> invalid and n.game.name <> invalid then gameName = n.game.name
                title = ""
                if n.title <> invalid then title = n.title
                viewers = 0
                if n.viewersCount <> invalid then viewers = n.viewersCount
                thumb = ""
                if n.previewImageURL <> invalid then thumb = n.previewImageURL

                if login <> ""
                    items.Push({
                        platform: "twitch",
                        login: login,
                        displayName: displayName,
                        title: title,
                        game: gameName,
                        viewers: viewers,
                        thumb: thumb,
                        playbackUrl: "",
                        isLive: true
                    })
                end if
            end if
        end for
    end if
    m.top.responseJson = FormatJson(items)
end sub



sub parseSearchResponse(res as Dynamic)
    items = []
    seen = {}
    if res <> invalid and res.data <> invalid
        if res.data.user <> invalid and res.data.user.login <> invalid
            u = res.data.user
            addUserNode(u, items, seen)
        end if
        if res.data.searchFor <> invalid and res.data.searchFor.channels <> invalid and res.data.searchFor.channels.edges <> invalid
            for each edge in res.data.searchFor.channels.edges
                if edge <> invalid and edge.item <> invalid and edge.item.login <> invalid
                    addUserNode(edge.item, items, seen)
                end if
            end for
        end if
    end if
    m.top.responseJson = FormatJson(items)
end sub



sub parseFavoritesResponse(csvLogins as String)
    items = []
    seen = {}
    if csvLogins = ""
        m.top.responseJson = FormatJson(items)
        return
    end if
    parts = csvLogins.Split(",")
    qParts = []
    kickParts = []
    idx = 0
    for each p in parts
        clean = LCase(p.Trim())
        if clean <> ""
            known = getKnownFavoriteChannel(clean)
            if known <> invalid
                items.Push(known)
            else if Left(clean, 5) = "kick:"
                kickParts.Push(Mid(clean, 6))
            else
                qParts.Push("u" + idx.ToStr() + ": user(login: " + chr(34) + clean + chr(34) + ") { login displayName broadcastSettings { title } stream { viewersCount game { name } previewImageURL(width: 440, height: 248) } }")
                idx = idx + 1
            end if
        end if
    end for
    if qParts.Count() > 0
        q = "{ " + qParts.Join(" ") + " }"
        res = postGql(q)
        if res <> invalid and res.data <> invalid
            for i = 0 to idx - 1
                key = "u" + i.ToStr()
                if res.data[key] <> invalid and res.data[key].login <> invalid
                    addUserNode(res.data[key], items, seen)
                end if
            end for
        end if
    end if
    for each kSlug in kickParts
        kRes = getJsonUrl("https://kick.com/api/v1/channels/" + kSlug)
        if kRes <> invalid and kRes.slug <> invalid
            isLive = (kRes.livestream <> invalid)
            viewers = 0
            title = "Canal Favorito na Kick"
            gameName = "Kick"
            if isLive
                if kRes.livestream.viewer_count <> invalid then viewers = kRes.livestream.viewer_count
                if kRes.livestream.session_title <> invalid then title = kRes.livestream.session_title
            end if
            disp = kSlug
            if kRes.user <> invalid and kRes.user.username <> invalid then disp = kRes.user.username
            pb = ""
            if kRes.playback_url <> invalid then pb = kRes.playback_url
            items.Push({
                platform: "kick",
                login: kSlug,
                displayName: "[KICK] " + disp,
                title: title,
                game: gameName,
                viewers: viewers,
                thumb: "",
                playbackUrl: pb,
                isLive: isLive
            })
        end if
    end for
    m.top.responseJson = FormatJson(items)
end sub



sub addUserNode(u as Dynamic, items as Object, seen as Object)
    login = u.login
    if seen.DoesExist(login) then return
    seen[login] = true

    displayName = login
    if u.displayName <> invalid then displayName = u.displayName
    title = ""
    if u.broadcastSettings <> invalid and u.broadcastSettings.title <> invalid
        title = u.broadcastSettings.title
    end if
    isLive = false
    viewers = 0
    gameName = "Offline"
    thumb = ""
    if u.stream <> invalid
        isLive = true
        if u.stream.viewersCount <> invalid then viewers = u.stream.viewersCount
        if u.stream.game <> invalid and u.stream.game.name <> invalid then gameName = u.stream.game.name else gameName = "Ao Vivo"
        if u.stream.previewImageURL <> invalid then thumb = u.stream.previewImageURL
    end if
    items.Push({
        platform: "twitch",
        login: login,
        displayName: displayName,
        title: title,
        game: gameName,
        viewers: viewers,
        thumb: thumb,
        playbackUrl: "",
        isLive: isLive
    })
end sub

function resolveDynamicTwitchLogin(query as String, fallbackLogin as String) as String
    cleanQuery = query.Trim()
    q = "{ searchFor(userQuery: " + chr(34) + cleanQuery + chr(34) + ", platform: " + chr(34) + "web" + chr(34) + ") { channels { edges { item { ... on User { login displayName stream { viewersCount } } } } } } }"
    res = postGql(q)
    if res <> invalid and res.data <> invalid and res.data.searchFor <> invalid and res.data.searchFor.channels <> invalid
        edges = res.data.searchFor.channels.edges
        if edges <> invalid
            bestLogin = ""
            maxViewers = -1
            for each e in edges
                if e <> invalid and e.item <> invalid and e.item.stream <> invalid
                    v = 0
                    if e.item.stream.viewersCount <> invalid then v = e.item.stream.viewersCount
                    if v > maxViewers and e.item.login <> invalid and e.item.login <> ""
                        maxViewers = v
                        bestLogin = e.item.login
                    end if
                end if
            end for
            if bestLogin <> "" then return bestLogin
        end if
    end if
    return fallbackLogin
end function

function resolvePlutoStream(chId as String) as String
    cleanId = chId
    if Left(cleanId, 6) = "pluto:" then cleanId = Mid(cleanId, 7)

    bootUrl = "https://boot.pluto.tv/v4/start?appName=web&appVersion=8.1.0&deviceType=web&deviceMake=Chrome&deviceModel=web&deviceId=6b7e51c8-8888-4444-9999-123456789abc&clientID=6b7e51c8-8888-4444-9999-123456789abc&clientModelNumber=1.0.0&clientDeviceType=0&deviceVersion=133.0.0"
    bootData = getJsonUrl(bootUrl)
    if bootData <> invalid and bootData.sessionToken <> invalid and bootData.stitcherParams <> invalid
        params = bootData.stitcherParams
        jwt = bootData.sessionToken
        return "https://ipv4.pluto.tv/api/tn/video/playout/v2/stitch/hls/channel/" + cleanId + "/master.m3u8?" + params + "&deviceVersion=133.0.0&jwt=" + jwt
    end if
    return ""
end function

sub fetchPlutoHlsUrl(param as String)
    url = resolvePlutoStream(param)
    if url <> ""
        m.top.streamUrl = url
        return
    end if
    m.top.errorMessage = "Transmissao Pluto TV temporariamente indisponivel."
    m.top.streamUrl = ""
end sub

sub fetchStreamHlsUrl(channelLogin as String)
    actualLogin = channelLogin
    if Left(channelLogin, 8) = "dynamic:"
        parts = channelLogin.Split(":")
        query = parts[1]
        fallback = ""
        if parts.Count() > 2 then fallback = parts[2]
        actualLogin = resolveDynamicTwitchLogin(query, fallback)
    end if

    q = "{ streamPlaybackAccessToken(channelName: " + chr(34) + actualLogin + chr(34) + ", params: {platform: " + chr(34) + "web" + chr(34) + ", playerBackend: " + chr(34) + "mediaplayer" + chr(34) + ", playerType: " + chr(34) + "embed" + chr(34) + "}) { value signature } }"
    res = postGql(q)
    if res <> invalid and res.data <> invalid and res.data.streamPlaybackAccessToken <> invalid
        tok = res.data.streamPlaybackAccessToken
        if tok.value <> invalid and tok.signature <> invalid
            http = CreateObject("roUrlTransfer")
            encodedToken = http.Escape(tok.value)
            sig = tok.signature
            rnd = Rnd(999999).ToStr()
            hlsUrl = "https://usher.ttvnw.net/api/channel/hls/" + actualLogin + ".m3u8?client_id=kimne78kx3ncx6brgo4mv6wki5h1ko&token=" + encodedToken + "&sig=" + sig + "&allow_source=true&allow_audio_only=true&fast_bread=true&p=" + rnd
            m.top.streamUrl = hlsUrl
            return
        end if
    end if
    m.top.errorMessage = "Canal offline ou indisponivel no momento (" + actualLogin + ")."
    m.top.streamUrl = ""
end sub
